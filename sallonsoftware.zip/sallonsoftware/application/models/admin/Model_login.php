<?php 

class Model_login extends CI_Model
{
	function __construct() {
parent::__construct();

}

	public function login($username,$password)
	{
		//$where = "name='Joe' AND status='boss' OR status='active'";
$this->db->where(['email'=>$username,'password'=>$password,'status'=>'1']);
$query = $this->db->get('tbl_admin');
if($query->num_rows()==1){
$rows = $query->row_array();
return $rows;
}
else{
	return false;
}
}



public function log_in_correctly($user,$pass) {  
        
          
       $this->db->where(['email'=>$user,'password'=>$pass,'status'=>'1']);
$query = $this->db->get('tbl_admin');
       
        /*$this->db->where('email',$user);  
        $this->db->where('password',$pass);  
        $query = $this->db->get('tbl_admin');  */
           if ($query->num_rows() == 1)  
        {  
        	
          $rows = $query->row_array();
return $rows; 
        } else {  
            return false;  
        }  
  
    }  

  
public function getLogindetails($email)
{
  return $this->db->get_where('tbl_admin',array('email'=>$email))->row();
}

public function getadmindetails1($oldpassword,$email)
{


  
    $query = $this->db->get_where('tbl_admin', array('email=' => $email, 'password' =>$oldpassword ))->row_array();
   

          return $query;
}

/* Update Custome query*/
public function updateData($table,$condition='',$arrayData)
  {
      $this->db->where($condition);
    
      return $this->db->update($table,$arrayData);
       
  }





}

