<!DOCTYPE html>
<!-- saved from url=(0039)https://easysalon.in/demo/dashboard.php -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		
		<title>1 new message</title>
		<link href="<?php echo base_url('assets/css/')?>ytLoad.jquery.css" rel="stylesheet" type="text/css">
		<!-- Bootstrap CSS -->
		<link href="<?php echo base_url('assets/css/')?>bootstrap.min.css" media="screen" rel="stylesheet">

		<!-- Main CSS -->
		<link href="<?php echo base_url('assets/css/')?>timepicker.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/')?>daterangepicker.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/')?>main.css" rel="stylesheet" media="screen">

		<!-- Ion Icons -->
		<link href="<?php echo base_url('assets/')?>fonts/icomoon/icomoon.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/')?>font-awesome.min.css" rel="stylesheet">
		
		<!-- C3 CSS -->
		<link href="<?php echo base_url('assets/css/')?>c3.css" rel="stylesheet">

		<!-- Circliful CSS -->
		<link href="<?php echo base_url('assets/css/')?>circliful.css" rel="stylesheet">


		<link href="<?php echo base_url('assets/css/')?>fullcalendar.min.css" rel="stylesheet">
		<link href="<?php echo base_url('assets/css/')?>fullcalendar.print.min.css" rel="stylesheet" media="print">
		<link href="<?php echo base_url('assets/css/')?>scheduler.min.css" rel="stylesheet">	
		
		<link href="<?php echo base_url('assets/css/')?>dialogify.css" id="dialogifyCss" rel="stylesheet" type="text/css">
		<link href="<?php echo base_url('assets/css/')?>lightbox.min.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" type="text/css" href="bootstrap-datepicker.min.css">
		<!-- <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.css"> -->


		<link rel="stylesheet" type="text/css" href="bootstrap-datetimepicker.css">


		<!--<link href="<?php echo base_url('assets/css/')?>https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
		<script src="<?php echo base_url('assets/js/'); ?>https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>-->
		<!-- HTML5 shiv and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="<?php echo base_url('assets/js/'); ?>js/html5shiv.js"></script>
			<script src="<?php echo base_url('assets/js/'); ?>js/respond.min.js"></script>
		<![endif]-->
		<script src="<?php echo base_url('assets/js/'); ?>twk-main.js" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>twk-vendor.js" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>twk-chunk-vendors.js" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>twk-chunk-common.js" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>twk-runtime.js" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>twk-app.js" charset="UTF-8" crossorigin="*"></script><script async="" src="default" charset="UTF-8" crossorigin="*"></script><script src="<?php echo base_url('assets/js/'); ?>jquery-latest.min.js" type="text/javascript"></script>
		<!-- Calendar CSS -->
		<script src="<?php echo base_url('assets/js/'); ?>jquery-3.5.1.min.js"></script>
		<script src="<?php echo base_url('assets/js/'); ?>jquery.js"></script>
		<link rel="stylesheet" href="jquery-ui.css">
		<!--<script src="<?php echo base_url('assets/js/'); ?>//code.jquery.com/jquery-3.3.1.js"></script>-->
		<!-- <script src="<?php echo base_url('assets/js/'); ?>//code.jquery.com/jquery-1.10.2.js"></script> -->
		<script src="<?php echo base_url('assets/js/'); ?>jquery-ui.js"></script>
		<link href="<?php echo base_url('assets/css/')?>fullcalendar.min(1).css" rel="stylesheet">
		<!--<link href="<?php echo base_url('assets/css/')?>../salonSoftFiles_new/css/calendar/custom-calendar.css" rel="stylesheet" />-->
		 <script src="<?php echo base_url('assets/js/'); ?>bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>jquery-form.js"></script>
		<link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
		<link rel="stylesheet" type="text/css" href="dataTables.bootstrap.min.css">
		<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>dataTables.bootstrap.min.js"></script>
		
		
		<!--<script src="<?php echo base_url('assets/js/'); ?>https://www.jqueryscript.net/demo/Dialog-Modal-Dialogify/dist/dialogify.min.js"></script>-->
		<script src="<?php echo base_url('assets/js/'); ?>dialogify.min.js"></script>
		<link rel="stylesheet" type="text/css" href="datatables.min.css">
        <script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>datatables.min.js"></script>
		
		<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>toastr.js"></script>
		<link rel="stylesheet" type="text/css" href="toastr.css">
		<!--<link rel="stylesheet" href="css/wickedpicker.css">
        <script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>js/wickedpicker.js"></script>-->
        <script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>bootstrap-datepicker.min.js"></script>
        <!-- <script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>../salonSoftFiles/js/bootstrap-timepicker.min.js"></script> -->
        <script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>bootstrap-datetimepicker.min.js"></script>
        
        <!-- New design css file -->
        <link href="<?php echo base_url('assets/css/')?>main(1).css" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/')?>main(2).css" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/')?>main(3).css" rel="stylesheet">
        <link href="<?php echo base_url('assets/css/')?>main(4).css" rel="stylesheet">
        <style>
            @media(max-width: 768px){
                .daterangepicker{
                    width: 318px!important;
                }
            }
		    table.table-bordered.dataTable tbody th:not(:last-child), table.table-bordered.dataTable tbody td:not(:last-child){
		        white-space: break-spaces;
		    }
        </style>
	<script charset="utf-8" src="twk-chunk-2d0d2b7c.js"></script><script charset="utf-8" src="twk-chunk-696bc286.js"></script><script charset="utf-8" src="twk-chunk-f1596d96.js"></script><script charset="utf-8" src="twk-chunk-48f46bef.js"></script><script charset="utf-8" src="twk-chunk-4fe9d5dd.js"></script><script charset="utf-8" src="twk-chunk-2d0b9454.js"></script><script charset="utf-8" src="twk-chunk-f163fcd0.js"></script><script charset="utf-8" src="twk-chunk-32507910.js"></script><style type="text/css">#jofdphofooig1643868972220 {outline:none !important;
visibility:visible !important;
resize:none !important;
box-shadow:none !important;
overflow:visible !important;
background:none !important;
opacity:1 !important;
filter:alpha(opacity=100) !important;
-ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important;
-mz-opacity:1 !important;
-khtml-opacity:1 !important;
top:auto !important;
right:0px !important;
bottom:0px !important;
left:auto !important;
position:fixed !important;
border:0 !important;
min-height:0px  !important;
min-width:0px  !important;
max-height:none  !important;
max-width:none  !important;
padding:0px !important;
margin:0px !important;
-moz-transition-property:none !important;
-webkit-transition-property:none !important;
-o-transition-property:none !important;
transition-property:none !important;
transform:none !important;
-webkit-transform:none !important;
-ms-transform:none !important;
width:auto !important;
height:auto  !important;
display:none !important;
z-index:2000000000 !important;
background-color:transparent !important;
cursor:none !important;
float:none !important;
border-radius:unset !important;
pointer-events:auto !important;
clip:auto !important;}</style><script src="<?php echo base_url('assets/js/'); ?>emojione.min.js" type="text/javascript" async="" defer=""></script><script src="<?php echo base_url('assets/js/'); ?>emojione.min.js" type="text/javascript" async="" defer=""></script><style type="text/css">@keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-moz-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-webkit-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}#vtslotn260981643868972383.open{animation : tawkMaxOpen .25s ease!important;}@keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}@-moz-keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}@-webkit-keyframes tawkMaxClose{from{opacity: 1;transform:translate(0, 0px);;}to{opacity: 0;transform:translate(0, 30px);;}}#vtslotn260981643868972383.closed{animation: tawkMaxClose .25s ease!important}</style></head>			<body onload="myalert()"><div class="loader-gif" style="display:none;position: fixed;width: 100%;height: 100%;background-color: #ffffffe8;z-index: 9999;">
	    <img src="loader.gif" alt="loader" style="max-width: 180px;position: absolute;left: 45%;top: 50%;">
	</div>
	
        <div style="background-color: #f1c40f; color: #333; padding: 5px; text-align: center; font-size: 16px;font-weight:600;">You are using easy salon demo.</div>
		<!-- Header starts -->
		<header>
		    <style>
		        
		    </style>
					<!-- Logo starts -->
			<a href="https://easysalon.in/demo/dashboard.php" class="logo" style="color: #fff !important; font-size:18px; font-weight:bold;">
				 Admin (Branch 1)			</a>
			<!-- Logo ends -->

			<!-- Header actions starts -->
			<ul id="header-actions" class="clearfix">
				<li class="list-box user-admin dropdown" style="z-index:1">
					<a id="drop4" href="https://easysalon.in/demo/dashboard.php#" role="button" class="dropdown-toggle" style="background-color: #Fff;" data-toggle="dropdown">
						<!--<i class="icon-account_circle"></i>-->
						<img src="1629668471.png" style="max-width: 65px;">
					</a>
					<ul class="dropdown-menu sm">
						<li class="dropdown-content">
							<!--<a href="#"><i class="icon-warning2"></i>Update Password<br><span>Your password will expire in 7 days.</span></a>-->
							<a href="https://easysalon.in/demo/changepassword.php">Change Password</a>
							<a href="https://easysalon.in/demo/logout.php">Logout</a>
						</li>
					</ul>
				</li>
			</ul>
			<!-- Header actions ends -->
			<span>
			    <a href="https://easysalon.in/demo/daily-follow-up.php">
			        <i class="fa fa-bell-o" style="max-width: 40px;border-radius: 50px;float: right;margin-top: 12px;color: #032f54; font-size: 20px; background-color: #fff; padding: 7px; " aria-hidden="true"></i>
			    </a>
		    </span>
		    		</header>
		<!-- Header ends -->
    <div class="clearfix"></div>
		<!-- Container fluid Starts -->
		<div class="container-fluid">

			<!-- Navbar starts -->

<nav class="navbar navbar-default">
	<div class="navbar-header">
		<!--<span class="navbar-text">Menu</span>-->
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-navbar" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	</div>
	
	<!-- Collect the nav links, forms, and other content for toggling -->
	<div class="collapse navbar-collapse" id="collapse-navbar">
		<ul class="nav navbar-nav">
			<li class="active">
				<a href="<?php echo base_url('Dashboard/welcomedashboard');?>"><i class="icon-shop"></i>Dashboard</a>
			</li>
			
			<li>
				<a href="https://easysalon.in/demo/enquiry.php"><i class="icon-add-user"></i>Enquiry</a>
			</li>
			<li>
			    <a href="https://easysalon.in/demo/dashboard.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-perm_phone_msg"></i>Appointments<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li class=""><a href="https://easysalon.in/demo/appointment.php">Software appointment</a></li>
					<li class=""><a href="https://easysalon.in/demo/webappointment.php">Web appointment </a></li>
					<!--<li class=""><a href="app-appointments.php">App appointment </a></li>-->
				</ul>
			</li>
			<li>
				<a href="https://easysalon.in/demo/billing.php"><i class="icon-credit-card"></i>Billing</a>
			</li>
			
			<li>
				<a href="https://easysalon.in/demo/clients.php"><i class="icon-emoji-happy"></i>Clients</a>
			</li>
			
			<li>
				<a href="https://easysalon.in/demo/feedback.php"><i class="icon-stars"></i>Feedbacks</a>
			</li>
			<li>
			<a href="https://easysalon.in/demo/dashboard.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-shopping-basket"></i>Products<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li class=""><a href="https://easysalon.in/demo/productsreport.php">Current stock</a></li>
										<li class=""><a href="https://easysalon.in/demo/addpurchase.php">Add stock</a></li>
					<li class=""><a href="https://easysalon.in/demo/vendor.php">Product vendor(s)</a></li>
					<li class=""><a href="https://easysalon.in/demo/productused.php">Use product in salon</a></li>
				</ul>
			</li>
			
			
			
							<li>
				<a href="https://easysalon.in/demo/dashboard.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-area-graph"></i>Reports<span class="caret"></span></a>
				<ul class="dropdown-menu">
				        <li class="">
							<a href="https://easysalon.in/demo/dailyreport.php">Daily Reports</a>
						</li> 
						<li class="">
							<a href="https://easysalon.in/demo/day-summary.php">Day Summary</a>
						</li>
						<li class="">
							<a href="https://easysalon.in/demo/billreport.php">Billing Reports</a>
						</li>
						<li class="">
							<a href="https://easysalon.in/demo/enquiryreport.php">Enquiry Reports</a>
						</li>
						<li class="">
							<a href="https://easysalon.in/demo/service_provider_report.php">Service Provider Reports</a>
						</li>
						<li class="">
							<a href="https://easysalon.in/demo/received-pending-payments.php">Received Pending Payments</a>
						</li>
						<li class="">
					        <a href="https://easysalon.in/demo/history.php">History</a>
					    </li>
						<li class="">
							<a href="https://easysalon.in/demo/balancereports.php">Balance Reports</a>
						</li>
						<li class="">
							<a href="https://easysalon.in/demo/otherreports.php">Advance Reports</a>
						</li>
												<li>
						    <a href="https://easysalon.in/demo/attendance.php">Attendance Report</a>
					    </li>
					    					    					</ul>
				</li>
						
			
			<li>
				<a href="https://easysalon.in/demo/dashboard.php#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-plus4"></i>Add &amp; Manage<span class="caret"></span></a>
				<ul class="dropdown-menu">		
					<li class="">
						<a href="https://easysalon.in/demo/expenses.php">Expenses</a>
					</li>
										<li class="">
					    <a href="https://easysalon.in/demo/packages.php">Packages</a>
				    </li>
				    <li class="">
				        <a href="https://easysalon.in/demo/coupons.php">Coupons</a>
				    </li>
				    					<li class="">
						<a href="https://easysalon.in/demo/beauticians.php">Service providers</a>
					</li>
					<li class="">
                		<a href="https://easysalon.in/demo/services_reminder.php">Automatic service reminder</a>
                	</li>
					<li class="">
						<a href="https://easysalon.in/demo/employees.php">Staff</a>
					</li>
					<!--<li class="">-->
					<!--    <a href="reward-points.php">Reward points</a>-->
					<!--</li>-->
					
				    					<li class="">
					    <a href="https://easysalon.in/demo/membership_list.php">Membership</a>
				    </li>
				    										<li class="">
						<a href="https://easysalon.in/demo/software_setting.php">Software setting</a>
					</li>
										<li class="">
						<a href="https://easysalon.in/demo/self-assessment-data.php">Self assessment data</a>
					</li>				
											<li>
						    <a href="https://easysalon.in/demo/mark_attendance.php">Mark attendance</a>
					    </li>
				    				</ul>
			</li>
		</ul>
	</div>
</nav><style type="text/css">
	.fc-time-grid-container{
		height: auto!important;
	}
	.fc-content{
	    cursor: pointer;
	}
	.fc-today-button, .fc-axis, .fc-resourceTimeGridDay-button, .fc-resourceTimeGridWeek-button, .fc-resourceDayGridMonth-button{
	   text-transform: capitalize;
	}
	.ui-autocomplete{
	    z-index: 9999;
	}
	.pending-appointment{
	    background-color: #f1c40f;
	    border-color: #f1c40f;
	}
	.cancelled-appointment{
	    background-color: #ff0000;
	    border-color: #ff0000;
	}
	.billed-appointment{
	    background-color: #048a04;
	    border-color: #048a04;
	}
	.checkedin-appointment{
	    background-color: #2d00a7;
	    border-color: #2d00a7;
	}
	
	.fc-time-grid .fc-slats {
	    /*z-index: 4;*/
	    /*pointer-events: none;*/
	 }

	.fc-resourceDayGridMonth-view .fc-widget-content, .fc-resourceDayGridMonth-view .fc-day-grid-container{
	    height: auto!important;
	    min-height: 8em!important;
	}

	.fc-time-grid .fc-event, .fc-time-grid .fc-bgevent{
	    min-height : 15px;
	}
	
	.fc-resourceDayGridMonth-view .fc-day-grid-container{
	    min-height:600px!important;
	}
	
	.fc-view {
        overflow-x: auto;
	 }
	
	
	.fc-scroller.fc-time-grid-container {
	    overflow: initial !important;
	 }
	
	.fc-axis {
        position: sticky;
        left: 0;
        background: white;
    }
    
    .popover {
        background: #fff;
        border-radius: 8px;
        border:1px solid #ccc;
	}
	.popover.top > .arrow:after { border-top-color: #ccc; }

</style>