
<!-- Navbar ends -->
<!-- Dashboard wrapper starts -->
<div class="dashboard-wrapper">
	
	<!-- Main container starts -->
	<div class="main-container">
		


		<!-- Row starts -->
		<div class="row gutter">
							<div class="col-lg-3 col-md-6 col-sm-6">
					<a href="javascript:void(0)" id="sales"><div class="mini-widget">
						<div class="mini-widget-heading clearfix">
							<div class="pull-left">Today Sales</div>
							<!-- <div class="pull-right"><i class="icon-arrow--right2"></i> 0%</div> -->
						</div>
						<div class="mini-widget-body clearfix" id="salesDashboardLoader">
							<div class="pull-left">
								<i class="icon-credit-card"></i>
							</div>
							<div class="pull-right number">INR <span id="todaysalesValue">16,000.00</span></div>
						<div class="divloader" style="padding: 0px; margin-top: 0px !important; display: none;"><div class="divloader_ajax_small"></div></div></div>
					</div></a>
				</div>

				<input type="hidden" value="2022-02-03" id="fromDate">
				<input type="hidden" value="2022-02-03" id="toDate">
				<div class="col-lg-3 col-md-6 col-sm-6">
					<a id="appointment"><div class="mini-widget red">
						<div class="mini-widget-heading clearfix">
							<div class="pull-left">Today Appointments</div>
							<!-- <div class="pull-right"><i class="icon-arrow--right2"></i>0%</div> -->
						</div>
						
						<div class="mini-widget-body clearfix" id="appointmentDashboardLoader">
							<div class="pull-left">
								<i class="icon-perm_phone_msg"></i>
							</div>
							<div class="pull-right number"><span id="todayappointmentValue">1</span></div>
						<div class="divloader" style="padding: 0px; margin-top: 0px !important; display: none;"><div class="divloader_ajax_small"></div></div></div>
					</div></a>
				</div>
									<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="javascript:void(0)" id="enquiry"><div class="mini-widget grey">
							<div class="mini-widget-heading clearfix">
								<div class="pull-left">Today Enquiry</div>
								<!-- <div class="pull-right"><i class="icon-arrow--right2"></i>0%</div> -->
							</div>
							<div class="mini-widget-body clearfix" id="enquiryDashboardLoader">
								<div class="pull-left">
									<i class="icon-add-user"></i>
								</div>
								<div class="pull-right number"><span id="enquiryValue">0</span></div>
							<div class="divloader" style="padding: 0px; margin-top: 0px !important; display: none;"><div class="divloader_ajax_small"></div></div></div>
						</div></a>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6">
						<a id="clients"><div class="mini-widget green">
							<div class="mini-widget-heading clearfix">
								<div class="pull-left">Clients Visit</div>
								<!-- <div class="pull-right"><i class="icon-arrow--right2"></i> 0%</div> -->
							</div>
							<div class="mini-widget-body clearfix" id="clientsDashboardLoader">
								<div class="pull-left">
									<i class="icon-emoji-happy"></i>
								</div>
								<div class="pull-right number"><span id="clientsValue">1</span></div>
							<div class="divloader" style="padding: 0px; margin-top: 0px !important; display: none;"><div class="divloader_ajax_small"></div></div></div>
						</div></a>
					</div>				</div>
				<div class="color-code-indecation">
				    <ul class="pull-right">
				        <li style="display:inline-block;margin-right:10px;"><span class="pending-appointment" style="height:11px;width:11px;display:inline-block;"></span> Pending</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="checkedin-appointment" style="height:11px;width:11px;display:inline-block;"></span> Checked In</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="billed-appointment" style="height:11px;width:11px;display:inline-block;"></span> Billed</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="cancelled-appointment" style="height:11px;width:11px;display:inline-block;"></span> Cancelled</li>
				    </ul>
				</div>
				<div class="clearfix"></div><br>
        		<div id="todaysalesDashboard"> 
        		</div> 
		
		
		<!-- Row ends -->
		
		
		
		<div id="calendar" class="fc-calendar fc fc-ltr fc-unthemed" style=""><div class="fc-toolbar fc-header-toolbar"><div class="fc-left"><div class="fc-button-group"><button type="button" class="fc-prev-button fc-button fc-button-primary" aria-label="prev"><span class="fc-icon fc-icon-chevron-left"></span></button><button type="button" class="fc-next-button fc-button fc-button-primary" aria-label="next"><span class="fc-icon fc-icon-chevron-right"></span></button></div><button type="button" class="fc-today-button fc-button fc-button-primary" disabled="">today</button></div><div class="fc-center"><h2>February 3, 2022</h2></div><div class="fc-right"><div class="fc-button-group"><button type="button" class="fc-resourceTimeGridDay-button fc-button fc-button-primary fc-button-active">day</button><button type="button" class="fc-resourceTimeGridWeek-button fc-button fc-button-primary">week</button><button type="button" class="fc-resourceDayGridMonth-button fc-button fc-button-primary">month</button></div></div></div><div class="fc-view-container"><div class="fc-view fc-resourceTimeGridDay-view fc-timeGrid-view" style=""><table class="" style="width: 1300px;"><thead class="fc-head"><tr><td class="fc-head-container fc-widget-header"><div class="fc-row fc-widget-header"><table class="" style="width: 1300px;"><thead><tr><th class="fc-axis fc-widget-header" style="width: 46.125px;"></th><th class="fc-resource-cell" data-resource-id="1">Test</th><th class="fc-resource-cell" data-resource-id="2">Poonam</th><th class="fc-resource-cell" data-resource-id="3">Riya</th><th class="fc-resource-cell" data-resource-id="4">Rahul</th><th class="fc-resource-cell" data-resource-id="5">RK</th><th class="fc-resource-cell" data-resource-id="6">Neha</th><th class="fc-resource-cell" data-resource-id="7">RASHMI</th></tr></thead></table></div></td></tr></thead><tbody class="fc-body"><tr><td class="fc-widget-content"><div class="fc-day-grid"><div class="fc-row fc-week fc-widget-content"><div class="fc-bg"><table class="" style="width: 1300px;"><tbody><tr><td class="fc-axis fc-widget-content" style="width: 46.125px;"><span>all-day</span></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="1"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="2"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="3"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="4"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="5"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="6"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="7"></td></tr></tbody></table></div><div class="fc-content-skeleton"><div class="calander-blank"></div><table style="width: 1300px;"><tbody><tr><td class="fc-axis" style="width: 46.125px;"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table></div><div class="fc-mirror-skeleton" style="top: 0px;"><table style="width: 1300px;"><tbody><tr><td class="fc-axis" style="width: 46.125px;"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></tbody></table></div></div></div><hr class="fc-divider fc-widget-header"><div class="fc-scroller fc-time-grid-container" style="overflow: hidden; height: 905.609px;"><div class="fc-time-grid"><div class="fc-bg"><table class="" style="width: 1300px;"><tbody><tr><td class="fc-axis fc-widget-content" style="width: 46.125px;"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="1"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="2"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="3"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="4"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="5"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="6"></td><td class="fc-day fc-widget-content fc-thu fc-today " data-date="2022-02-03" data-resource-id="7"></td></tr></tbody></table></div><div class="fc-slats"><table class="" style="width: 1300px;"><tbody><tr data-time="10:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>10am</span></td><td class="fc-widget-content"></td></tr><tr data-time="10:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="11:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>11am</span></td><td class="fc-widget-content"></td></tr><tr data-time="11:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="12:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>12pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="12:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="13:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>1pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="13:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="14:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>2pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="14:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="15:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>3pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="15:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="16:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>4pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="16:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="17:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>5pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="17:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="18:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>6pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="18:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr><tr data-time="19:00:00"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"><span>7pm</span></td><td class="fc-widget-content"></td></tr><tr data-time="19:30:00" class="fc-minor"><td class="fc-axis fc-time fc-widget-content" style="width: 46.125px;"></td><td class="fc-widget-content"></td></tr></tbody></table></div><hr class="fc-divider fc-widget-header" style=""><div class="fc-content-skeleton"><div class="calander-blank"></div><table style="width: 1300px;"><tbody><tr><td class="fc-axis" style="width: 46.125px;"></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"><a class="fc-time-grid-event fc-event fc-start fc-end billed-appointment" data-original-title="" title="" style="inset: 44.8906px 0% -90.2812px; z-index: 1;"><div class="fc-content"><div class="fc-time" data-start="11:00" data-full="11:00 AM - 12:00 PM"><span>11:00 - 12:00</span></div><div class="fc-title">Urvashi</div></div></a><a class="fc-time-grid-event fc-event fc-start fc-end billed-appointment fc-short" data-original-title="" title="" style="inset: 90.2812px 0% -105.875px; z-index: 1;"><div class="fc-content"><div class="fc-time" data-start="12:00" data-full="12:00 PM - 12:20 PM"><span>12:00 - 12:20</span></div><div class="fc-title">Urvashi</div></div></a></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td><td><div class="fc-content-col"><div class="fc-event-container fc-mirror-container"></div><div class="fc-event-container"></div><div class="fc-highlight-container"></div><div class="fc-bgevent-container"></div><div class="fc-business-container"></div><div class="fc-now-indicator fc-now-indicator-line" style="top: 80.3206px;"></div></div></td></tr></tbody></table><div class="fc-now-indicator fc-now-indicator-arrow" style="top: 80.3206px;"></div></div></div></div></td></tr></tbody></table></div></div></div> 
		<!-- Row starts -->
	</div>
	<!-- Main container ends -->
	
</div>
<!-- Dashboard Wrapper End -->

</div>
<!-- Container fluid ends -->

