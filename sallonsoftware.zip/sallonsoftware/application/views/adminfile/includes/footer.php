<footer>
	© Easy Salon &amp; Spa Software <span>Powered by <a href="http://13designstreet.com/" target="_blank" style="color:#ffb400">13DesignStreet</a></span>
</footer>

<style type="text/css">
	.alltimes .hour_0, .alltimes .hour_1, .alltimes .hour_2, .alltimes .hour_3, .alltimes .hour_4, .alltimes .hour_5, .alltimes .hour_6, .alltimes .hour_7, .alltimes .hour_8, .alltimes .hour_9, .alltimes .hour_20, .alltimes .hour_21, .alltimes .hour_22, .alltimes .hour_23{
			pointer-events: none;
			opacity : 0.3;
		}</style>

<script type="text/javascript">
	$( document ).ready(function() {
	    
	    setInterval(function(){
        	$.ajax({
        			url: "ajax/setsession.php",
        			type: "POST",
        			success:function(){
        			}
        		});
        },600000);

	    $('.tableprint').DataTable({
			dom: 'lBfrtip',
			"bProcessing": true,
			"aaSorting":[],
			'lengthMenu': [[10, 25, 50, 100, 99999999], [10, 25, 50, 100, 'All']],
			"aoColumnDefs": [
                { "bSortable": false, "aTargets": [ 0, 7 ] }, 
            ],
			buttons: [	{
				extend: 'excelHtml5',
				text: '<i class="fa fa-file-excel-o"></i> Excel',
				titleAttr: 'Export to Excel',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'csvHtml5',
				text: '<i class="fa fa-file-text-o"></i> CSV',
				titleAttr: 'CSV',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'print',
				exportOptions: {
					columns: ':visible'
				},
				customize: function(win) {
					$(win.document.body).find( 'table' ).find('td:last-child, th:last-child').remove();
				}
			},
			],
			"fnDrawCallback": function (oSettings) {
				$("#smstab_wrapper").find('.pagination').append('<li class="paginate_button"><a href="javascript:void(0)" style="border-radius:0px;background-color:#2877aa;border-color:#2877aa;color:#fff;" class="btn btn-info" onclick="sendsms()"><i style="margin-left:0px;" class="fa fa-paper-plane" aria-hidden="true"></i>Send SMS</a></li>');
			},
		});
		
		var tableFB = $('.grid').DataTable({
			"dom": 'lBfrtip',
			'lengthMenu': [[10, 25, 50, 100, 99999999], [10, 25, 50, 100, 'All']],
			"buttons": [
			'copy', 'csv', 'excel', 'print'
			],
			"bProcessing": true,
			"aaSorting":[],
			'columnDefs': [ {
				'targets': [0], // column index (start from 0)
				'orderable': false, // set orderable false for selected columns
			}],
		});
		var buttons = new $.fn.dataTable.Buttons(tableFB, {
		     buttons: [{
					extend: 'excelHtml5',
					text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
					titleAttr: 'Export to Excel',
					title: 'AK Unisex salon',
					exportOptions: {
						columns: ':not(:last-child)',
					}
				}
		    ]
		}).container().appendTo($('#download-btn'));

		buttons[0].classList.add('d-block');
		buttons[0].classList.add('custom-download-btn');
		buttons[0].classList.add('pull-right');
		buttons[0].classList.remove('dt-buttons');
		$('.custom-download-btn a').removeClass('btn-default');
		// $('.custom-download-btn a').attr({"data-toggle":"tooltip","data-placement":"top","data-html":"true"});
		$('.custom-download-btn a').addClass('btn-warning pull-right download-btn mr-left-5');

		$('.order_date_desc').DataTable({
			"dom": 'lBfrtip',
			'lengthMenu': [[10, 25, 50, 100, 99999999], [10, 25, 50, 100, 'All']],
			"buttons": [
			'copy', 'csv', 'excel', 'print'
			],
			"bProcessing": true,
			"aaSorting":[[0,'desc']],
			'columnDefs': [ {
				'targets': [0], // column index (start from 0)
				'orderable': false, // set orderable false for selected columns
			}],
		});  
		
		
		$('.gridsms').DataTable({
			"bProcessing": true,
			"aaSorting":[],
			"fnDrawCallback": function (oSettings) {
				$("#gridsms_wrapper").find('.pagination').append('<li class="paginate_button"><button class="btn-info" style="float : right;" onclick="sendsms()">Send SMS</button></li>');
			}
		});
		var table = $('.table_datatable').DataTable( {
			dom: 'lBfrtip',
			'lengthMenu': [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'All']],
			"aaSorting":[],
			buttons: [	{
				extend: 'excelHtml5',
				text: '<i class="fa fa-file-excel-o"></i> Excel',
				titleAttr: 'Export to Excel',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			// {
			// 	extend: 'csvHtml5',
			// 	text: '<i class="fa fa-file-text-o"></i> CSV',
			// 	titleAttr: 'CSV',
			// 	title: '',
			// 	exportOptions: {
			// 		columns: ':not(:last-child)',
			// 	}
			// },
			// {
			// 	extend: 'print',
			// 	exportOptions: {
			// 		columns: ':visible'
			// 	},
			// 	customize: function(win) {
			// 		$(win.document.body).find( 'table' ).find('td:last-child, th:last-child').remove();
			// 	}
			// },
			],
			
		} );

		// To move download button in another div out of the dataTables
		var buttons = new $.fn.dataTable.Buttons(table, {
		     buttons: [{
					extend: 'excelHtml5',
					text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
					titleAttr: 'Export to Excel',
					title: 'AK Unisex salon',
					exportOptions: {
						columns: ':not(:last-child):not(.not-export-column)',
					}
				}
		    ]
		}).container().appendTo($('#download-btn'));

		buttons[0].classList.add('d-block');
		buttons[0].classList.add('custom-download-btn');
		buttons[0].classList.add('pull-right');
		buttons[0].classList.remove('dt-buttons');
		$('.custom-download-btn a').removeClass('btn-default');
		// $('.custom-download-btn a').attr({"data-toggle":"tooltip","data-placement":"top","data-html":"true"});
		$('.custom-download-btn a').addClass('btn-warning pull-right download-btn mr-left-5');
		
		$('#printtable').DataTable({
			dom: 'lBfrtip',
			"aaSorting":[],
			buttons: [	
			'excelHtml5',
			'csvHtml5',
			'print'
			]
		});
		
		$('#excel').click(function(){
			var reportName=$(this).parents('.main-container').find('h4').html();    
			$("table").table2excel({
				exclude: ".noExl",
				name: "Worksheet Name",
				filename: reportName,
				fileext: ".xls",
				exclude_img: true,
				exclude_links: true,
				exclude_inputs: true,
			});
		});
	});
	function myalert() {
		toastr.success("Welcome Admin To AK Unisex salon ");$(".loading").attr("style","display:none")		
			}
	
	
	
	function setTwoNumberDecimal(e) {
		if(parseFloat($(e).val())>0){
			$(e).val(parseFloat($(e).val()).toFixed(2)) ;
			}else{
			$(e).val(0);
		}
	}
	
	
	// $('.main-container').append('<div class="loading">Loading&#8230;</div>');
	function loader(){
		var flag=true;
		$('form#main-form').find(':input[required]').each(function(){
			if($(this).val() == ''){
				flag=false;
			}
		});
		if(flag){	
			$('.main-container').append('<div class="loading">Loading&#8230;</div>');
		}
	}
	function deleteloader(){
		
		$('.main-container').append('<div class="loading">Loading&#8230;</div>');
	}

	// function to download excel file

	function samplefile(filename){
		window.location.href = 'xlsxsamlefiles/sample_'+filename+'.xlsx';
	}
	
	function deleteDisabled(){
	    alert('Delete option is disabled in demo mode.');
	}


	// function to clear all form and error message when modal close button is clicked.

	function clearModalForm(errorDiv, modalParentDiv){
		$('#'+errorDiv).text('');
		$('#'+modalParentDiv+' input').val('');
	}

	$(document).ready(function(){
		$("[data-toggle=tooltip]").tooltip();
		$('.disableOutsideClick').modal({
		    show: false,
		    keyboard: false,
		    backdrop: 'static'
		});	

		// Bookmarking smooth scrollng

		$(document).on('click', 'a[href^="#"]', function (event) {
		    event.preventDefault();

		    $('html, body').animate({
		        scrollTop: $($.attr(this, 'href')).offset().top
		    }, 500);
		});

	});

	// function to check start and end time of salon

	function checkTime(id, time, errorDivId){
		var d = new Date();
		var sstime, eetime;
		$.ajax({  
        url:"ajax/system_details.php",
        method:"POST",
        dataType: "json",
        data: {'action':'getStartEndTime'},
        success:function(response){
            	if(response.status == '1'){
            		sstime = response.starttime;
            		eetime = response.endtime;
               		var stime = Date.parse('20 Aug 2000 '+sstime);
					var etime = Date.parse('20 Aug 2000 '+eetime);
					var cpmtime = Date.parse('20 Aug 2000 '+time+':00');
					if(stime == '' || etime == ''){
						//alert('Please select working hours in system setting tab.');
					} else {
						if(cpmtime < stime || cpmtime > etime){
							$('#'+id).val('');
							if(errorDivId != ''){
								$('#'+errorDivId).text('Select between '+onTimeChange(sstime)+' to '+onTimeChange(eetime));
								appointmenttime();
								$('.ser').prop('disabled',true);
							}
						} else {
							$('#'+errorDivId).text('');
							$('.ser').prop('disabled',false);
							appointmenttime();
						}
					}
               	} else if(response.status == '0'){
               		$('#'+id).val('');
               		$('#'+errorDivId).text('Appointment not available');
               		$('.ser').prop('disabled',true);
               	}
            }
       	});
	}

	// function to check appointment time of salon

	function checkappTime(id, time, errorDivId){
		var sstime, eetime;
		var date = $('#date').val();
		if(date != ''){
			if(time != ''){
				$('#date').removeClass('invalid');
				$.ajax({  
		        url:"ajax/system_details.php",
		        method:"POST",
		        dataType: "json",
		        data: {date : date, 'action':'checkapptime'},
		        success:function(response){
		            	if(response.status == '1'){
		            		sstime = response.starttime;
		            		eetime = response.endtime;
		               		var stime = Date.parse('20 Aug 2000 '+sstime);
							var etime = Date.parse('20 Aug 2000 '+eetime);
							var cpmtime = Date.parse('20 Aug 2000 '+time+':00');
							if(stime == '' || etime == ''){
								//alert('Please select working hours in system setting tab.');
							} else {
								var et_status = '0';
								if((cpmtime < stime || cpmtime > etime) && et_status!= '1'){
									$('#'+id).val('');
									if(errorDivId != ''){
										$('#'+errorDivId).text('Select between '+onTimeChange(sstime)+' to '+onTimeChange(eetime));
										// appointmenttime();
										//$('.ser').prop('disabled',true);
										//$('.ser').val('');
									}
								} else {
									var d = new Date();
									var dd = new Date(date);
									if(d.toDateString() === dd.toDateString()){
										if(Date.parse("'"+date+"' '"+time+':59') <	 Date.parse(d)){
											$('#'+errorDivId).text('Past time not allowed');
											$('#time').val('');
										} else {
											$('#'+errorDivId).text('');
											//$('.ser').prop('disabled',false);
											//$('.ser').val('');
											$('#close_time').val(eetime);
											$('#time').removeClass('invalid');
										}
									} else{
										$('#'+errorDivId).text('');
										//$('.ser').prop('disabled',false);
										//$('.ser').val('');
										$('#close_time').val(eetime);
										$('#time').removeClass('invalid');
									}
									if($('.ser').val() != ''){
										appointmenttime();
									}
								}
							}
		               	} else if(response.status == '0'){
		               		$('#'+id).val('');
		               		$('#'+errorDivId).text('Appointment not available');
		               		//$('.ser').prop('disabled',true);
		               	}
		            }
		       	});
			} else {
				$('#'+errorDivId).text('Please select time');
			}
		} else {
			$('#date').addClass('invalid');
			$('#time').val('');
			$('#time').removeClass('invalid');
		}
	}


	// function to change time in am/pm

	function onTimeChange(time) {
	  var timeSplit = time.split(':'), hours, minutes, meridian;
	  hours = timeSplit[0];
	  minutes = timeSplit[1];
	  if (hours > 12) {
	    meridian = 'PM';
	    hours -= 12;
	  } else if (hours < 12) {
	    meridian = 'AM';
	    if (hours == 0) {
	      hours = 12;
	    }
	  } else {
	    meridian = 'PM';
	  }
	  return((hours<9?'0':'')+hours + ':' + minutes + ' ' + meridian);
	}

	// functiont to change 12 hour time into 24 time

	function time12to24(time){
		var time = time;
		var hours = Number(time.match(/^(\d+)/)[1]);
		var minutes = Number(time.match(/:(\d+)/)[1]);
		var AMPM = time.match(/\s(.*)$/)[1];
		if(AMPM == "PM" && hours<12) hours = hours+12;
		if(AMPM == "AM" && hours==12) hours = hours-12;
		var sHours = hours.toString();
		var sMinutes = minutes.toString();
		if(hours<10) sHours = "0" + sHours;
		if(minutes<10) sMinutes = "0" + sMinutes;
		return (sHours + ":" + sMinutes + ":00");
	}
	// check date availability

	function dateAvailability(date){
		if(date != ''){
			$('#date').removeClass('invalid');
			$.ajax({  
		        url:"ajax/system_details.php",
		        method:"POST",
		        dataType: "json",
		        data: {'date': date, 'action':'checkDate'},
		        success:function(response){
		        	if(response.status == 0){
		        		$('#date').val('');
		        		$('#dateerror').text('Salon will be closed');
		        	} else {
		        		$('#dateerror').text('');
		        		checkappTime('time', $('#time').val(), 'apptime');
		        	}
		        }
		    });
		} else {
			$('#date').addClass('invalid');
		}
	}
	
</script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>ajax.js"></script>
<!--Full Calendar With scheduler---->
<script src="<?php echo base_url('assets/js/'); ?>moment.min.js"></script>
<script src="<?php echo base_url('assets/js/'); ?>fullcalendar.min.js"></script>
<script src="<?php echo base_url('assets/js/'); ?>scheduler.min.js"></script>
<script src="<?php echo base_url('assets/js/'); ?>jquery.table2excel.js"></script>
<!-- D3 JS -->
<script src="<?php echo base_url('assets/js/'); ?>d3.v3.min.js"></script>

<!-- C3 Graphs -->
<script src="<?php echo base_url('assets/js/'); ?>c3.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>jquery.transit.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>ytLoad.jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>lightbox.min.js"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>formFieldsValidations.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>daterangepicker.js"></script>

<!-- new  version calander js files -->

<script src="<?php echo base_url('assets/js/'); ?>main.js"></script>
<script src="<?php echo base_url('assets/js/'); ?>main.js(1)"></script>
<script src="<?php echo base_url('assets/js/'); ?>main.js(2)"></script>
<script src="<?php echo base_url('assets/js/'); ?>main.js(3)"></script>
<script src="<?php echo base_url('assets/js/'); ?>main.js(4)"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js(1)"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js(2)"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js(3)"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js(4)"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/'); ?>main.min.js(5)"></script>

<script>
	function dp(){
	  	$('.date').datepicker({
			format: "yyyy-mm-dd",
			todayBtn: "linked",
			todayHighlight: true,
			autoclose: true,
			weekStart: 1,
			datesDisabled : [''],
			daysOfWeekDisabled : []
		});

		$('.urdate').datepicker({  //un restricted date
			format: "yyyy-mm-dd",
			todayBtn: "linked",
			todayHighlight: true,
			autoclose: true,
			weekStart: 1
		});
		
		$('.min_present_date').datepicker({
			format: "yyyy-mm-dd",
			todayBtn: "linked",
			todayHighlight: true,
			autoclose: true,
			weekStart: 1,
			startDate: "today"
		});
		
		$('.dob_annv_date').datepicker({
		    format: "yyyy-mm-dd",
			todayBtn: "linked",
			todayHighlight: true,
			autoclose: true,
			weekStart: 1,
			endDate: "today"
		});
	}
	function time(){
		$(".time").datetimepicker({
	        format: "HH:ii P",
	        showMeridian: true,
	        autoclose: true,
	        pickDate: false,
	        startView: 1,
    		maxView: 1
	    });
	    $(".datetimepicker").find('thead th').remove();
  		$(".datetimepicker").find('thead').append($('<th class="switch text-warning">').html('Pick Time'));
  		$(".datetimepicker").find('tbody').addClass('alltimes');
  		$('.switch').css('width','190px');

	}
	function maintime(){
		$(".maintime").datetimepicker({
	        format: "HH:ii P",
	        showMeridian: true,
	        autoclose: true,
	        pickDate: false,
	        startView: 1,
    		maxView: 1
	    });
	    $(".datetimepicker").find('thead th').remove();
  		$(".datetimepicker").find('thead').append($('<th class="switch text-warning">').html('Pick Time'));
  		$(".datetimepicker").find('tbody').addClass('maintime');
  		$('.switch').css('width','190px');
	}


	$(document).ready(function() {

	    $('[data-toggle="tooltip"]').tooltip();
	  // $ = jQuery.noConflict();
	  	$('input[range-attr="daterange"]').daterangepicker({
	    	opens: 'right'
	  	});

	 //  	$('#btnAdd').click(function(){
		// 	time();
		// });

		dp();
		time();
		maintime();
		$('input[type=number]').attr('min','0');
// 		$('input[type=number]').attr('maxLength','11');
// 		$('input[type=number]:not(".disc_row")').attr('oninput','this.value = Math.abs(this.value); javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);');
		$('input.price[type=number]').change(function(){
			$(this).val(parseFloat($(this).val(),10).toFixed(3).slice(0,-1));
		});
	});
	
	function pendingpaymode(mode_id, modeDiv){
		var options = 0;
		var totalVal = parseFloat(modeDiv.parent().parent().find('.pendtotal').val());
		if(totalVal == 0){
			modeDiv.val('1');
		} else {
	        var modeDiv = modeDiv.parent().parent();
    		var wallet_money = parseFloat($('#wallet_money').val());
    		var reward_point = parseInt($('#reward_point').val());
    		if(mode_id == '7'){	
    			if(totalVal != 0){
    				if(wallet_money == '0' || wallet_money == ''){
    					toastr.warning('Wallet is empty.');
    					modeDiv.find('.mthd').val('1');
    				} 
    				else {
    					var price_cal = parseFloat(wallet_money);
    					if(totalVal < wallet_money){
    						modeDiv.find('.amtpay').val(totalVal);
    					} else {
    						modeDiv.find('.amtpay').val(price_cal);
    					} 
    					if(reward_point == '' || reward_point == '0'){
    
    					} else {
    						$('#reward_point').val(reward_point);
    						$('#earned_points').text(reward_point);
    					}
    				}
    			}
    		} else if(mode_id == '9'){
    			if(totalVal != 0){
    				if(reward_point == '' || reward_point == '0'){
    					modeDiv.find('.amtpay').val('0');
    					toastr.warning('Don\'t have any reward point.');
    					modeDiv.find('.mthd').val('1');
    					sumup();
    				} else {
    					var point;
    					var point_price = 1.000;
    					var redeem_point = 10;
    					var pprice = parseFloat(totalVal);
    					if(reward_point > 1000){
    						point = 1000;
    					} else {
    						point = reward_point;
    					}
    					var price_cal = (parseInt(point)/parseInt(redeem_point))*parseInt(point_price);
    					
    					if(pprice > price_cal){
    						modeDiv.find('.amtpay').val(price_cal); 
    					} else {
    						modeDiv.find('.amtpay').val(pprice);
    					}
    				}
    			}
    		} else {
    			modeDiv.find('.amtpay').val('0');
    		}   
		}
	}
	
	function maxpendpayment(pend_amount, amount, currDiv){
	    var pending_amount = parseFloat(pend_amount);
	    if(amount == ''){
	        var amount = 0;
	    } else {
	        var amount = parseFloat(amount);
	        currDiv.removeClass('invalid');
	    }
    	var paid = 0;
		var redeem_point = 10;
		var max_points = 1000;
		var mainDiv = currDiv.parent().parent();
		var currentDiv = currDiv;
		var rewardPoint = $('#reward_point').val();
		var walletMoney = $('#wallet_money').val();
		paid += parseFloat(currDiv.val()||0);
		if(parseFloat(paid) > pending_amount){
			toastr.warning('Amount exceeded total amount.');
			currentDiv.val(0);
			sumup();
		}
		else if(mainDiv.find('.mthd').val() == '9'){
			if(rewardPoint == '0'){
				toastr.warning('Don\'t have any reward point.');
			} else if(rewardPoint > 0){
				if(parseFloat((currentDiv.val()*redeem_point)) > parseFloat(max_points)){
			        toastr.warning('You can redeem max '+max_points+' points ( '+(max_points/redeem_point) +' INR ) at a time.');
					currentDiv.val(0);
			    }
				else if(parseFloat((currentDiv.val()*redeem_point)) > parseFloat(rewardPoint)){
					toastr.warning('You have only '+rewardPoint+' reward points');
					currentDiv.val(0);
				}
			}
		} else if(mainDiv.find('.mthd').val() == '7'){
			if(walletMoney == '0'){
				toastr.warning('Wallet is empty.');
			} else if(walletMoney > 0){
				
				if(parseFloat(currentDiv.val()) > parseFloat(walletMoney)){
					toastr.warning('You have '+walletMoney+' INR in your wallet account.');
					currentDiv.val(0);
				}
			}
		}
	}
	
	function pendingPayment(div){
	    var curDiv = div.parent().parent();
	    var payamount = curDiv.find('.amtpay').val();
	    if(payamount == '0'){
	        curDiv.find('.amtpay').addClass('invalid');
	    } else {
	        curDiv.find('.amtpay').removeClass('invalid');
	        var pay_amount = curDiv.find('.amtpay').val();
	        var clientid = curDiv.find('.clientid').val();
	        var inv_id = curDiv.find('.inv_id').val();
	        var method = curDiv.find('.mthd').val();
	        var pend = curDiv.find('.pendtotal').val();
	        var branch_id = curDiv.find('.branch_id').val();
	        $.ajax({
	            url : "ajax/get_pending_payments.php",
    	        type : "post",
    	        dataType : 'json',
    	        data : {action : 'apply_pending_payment', client_id : clientid, inv_id : inv_id, method : method, amount : pay_amount, branch_id : branch_id},
    	        success : function(res){
    	            if(res.status == '1'){
    	                toastr.success('Amount paid successfully.');
    	                if(parseFloat(pend) > parseFloat(pay_amount)){
    	                    curDiv.find('.pri').text(parseFloat(pend)-parseFloat(pay_amount));
    	                    curDiv.find('.pendtotal').val(parseFloat(pend)-parseFloat(pay_amount));
    	                    var pending = parseFloat(pend)-parseFloat(pay_amount);
    	                    curDiv.find('.amtpay').val('0');
    	                    curDiv.find('.amtpay').attr('onkeyup','maxpendpayment('+pending+',this.value, $(this))');
    	                    curDiv.find('.amtpay').attr('onblur','maxpendpayment('+pending+',this.value, $(this))');
    	                    curDiv.find('.amtpay').val('0');
    	                    curDiv.find('.mthd').val('1');
    	                    
    	                    clientView(clientid);
    	                } else {
    	                    clientView(clientid);
    	                    curDiv.remove();
    	                }
    	                var size = $('#ppaymentModal table tbody tr').length;
    	                if(size <= 0){
    	                    $('#ppaymentModal').modal('hide');
    	                }
    	            } else {
    	                toastr.warning('Amount not paid, please try again.');
    	            }
    	        }
	        });
	    }
	}
	function pendingPaymentSingleInvoice(div){
	    var curDiv = div.parent().parent();
	    var payamount = curDiv.find('.amtpay').val();
	    if(payamount == '0'){
	        curDiv.find('.amtpay').addClass('invalid');
	    } else {
	        curDiv.find('.amtpay').removeClass('invalid');
	        var pay_amount = curDiv.find('.amtpay').val();
	        var clientid = curDiv.find('.clientid').val();
	        var inv_id = curDiv.find('.inv_id').val();
	        var method = curDiv.find('.mthd').val();
	        var pend = curDiv.find('.pendtotal').val();
	        var branch_id = curDiv.find('.branch_id').val();
	        $.ajax({
	            url : "ajax/get_pending_payments.php",
    	        type : "post",
    	        dataType : 'json',
    	        data : {action : 'apply_pending_payment', client_id : clientid, inv_id : inv_id, method : method, amount : pay_amount, branch_id : branch_id},
    	        success : function(res){
    	            if(res.status == '1'){
    	                toastr.success('Amount paid successfully.');
    	                localStorage.setItem('invoice_paid', 'paid_success');
    	                window.location.href = 'clientprofile.php?cid='+clientid;
    	            } else {
    	                toastr.warning('Amount not paid, please try again.');
    	            }
    	        }
	        });
	    }
	}
	
	function contact_no_length(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit > 0 && digit < 10){
	        currDiv.val('');
	        $('#digit_error').text('Please enter 10 digit number.');
	    } else {
	        $('#digit_error').text('');
	    }
	}
	
	function othercontact(currDiv, phone_number){
	    var digit = phone_number.length;
	    if(digit != 10){
	        currDiv.parent().find('input').val('');
	        currDiv.parent().find('.conterror').text('Please enter 10 digit number.');
	    } else {
	        currDiv.parent().find('.conterror').text('');
	    } 
	   // else {
	       // currDiv.parent().find('.conterror').text('Please enter 10 digit number.');
	   // }
	}
	
	function maxcommissionper(currDiv, divVal){
	    if(divVal > 100){
	        currDiv.val('100');
	    }
	}
</script>




<!-- Payment Modal -->
<div id="paymentModal" class="modal fade" role="dialog">
	<div class="modal-dialog" style="width:1000px">
		
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h4 class="modal-title">Pending payments</h4>
			</div>
			<div class="modal-body">
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
		
	</div>
</div>


<!-- Package Modal -->
<div id="packageModal" class="modal disableOutsideClick fade" role="dialog">
	<div class="modal-dialog modal-lg">		
		<!-- Modal content-->
		<div class="modal-content">
			
		</div>
		
	</div>
</div>

<!-- Refferal Modal -->
<div id="refModal" class="modal fade" role="dialog">
	<div class="modal-dialog">		
		<!-- Modal content-->
		<div class="modal-content">
			
		</div>
		
	</div>
</div>	

<!-- Package Modal -->
<div id="ppaymentModal" class="modal disableOutsideClick fade" role="dialog">
	<div class="modal-dialog modal-lg">		
		<!-- Modal content-->
		<div class="modal-content">
			
		</div>
		
	</div>
</div>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d2eda76bfcb827ab0cc3622/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>		

<script>
	
	
	$(document).ready(function(){
		var now = new Date();
		var startDate=$('#fromDate').val();
		var endDate  =$('#toDate').val()
		today_SAEC_values(startDate,endDate,'sales');
		today_SAEC_values(startDate,endDate,'appointment');
		today_SAEC_values(startDate,endDate,'enquiry');
		today_SAEC_values(startDate,endDate,'clients');
		$('#sales,#appointment,#enquiry,#clients').on('click',function(){
			var type=$(this).attr('id');
			infoWithFilter(startDate,endDate,type);
			today_SAEC_values(startDate,endDate,type);
		});
		
		
		autocomplete_serr();
		
	});
	
	function dateFilter(date,type){
		// var type=$(this).attr('id');
		var date = date.split("-");
		if(date == ''){
			var startDate = '';
			var endDate = '';
		} else {
			var startDate = isoDate(date[0]);
			var endDate = isoDate(date[1]);
		}
		infoWithFilter(startDate,endDate,type);
		today_SAEC_values(startDate,endDate,type);
	}
	
	// jquery function to change daterange date in iso date standard  Y-m-d (2019-11-01)

	function isoDate(date){	
		var datespit = date.split('/');
		var day = datespit[1].replace(' ','');
		var month = datespit[0].replace(' ','');
		var year = datespit[2].replace(' ','');
		return year+'-'+month+'-'+day;
	}
	
	function today_SAEC_values(startDate,endDate,type){
		$.ajax({
			beforeSend: function () {
				if(type==='sales'){
					$('#salesDashboardLoader').append('<div class="divloader" style="margin-top:0px !important;padding:0px"><div class="divloader_ajax_small"></div></div>');
					}else if(type === 'appointment'){
					$('#appointmentDashboardLoader').append('<div class="divloader" style="margin-top:0px !important;padding:0px"><div class="divloader_ajax_small"></div></div>');
					}else if(type === 'enquiry'){
					$('#enquiryDashboardLoader').append('<div class="divloader" style="margin-top:0px !important;padding:0px"><div class="divloader_ajax_small"></div></div>');
					}else if(type === 'clients'){
					$('#clientsDashboardLoader').append('<div class="divloader" style="margin-top:0px !important;padding:0px"><div class="divloader_ajax_small"></div></div>');
				}	
			},
			url: "ajax/today_SAEC_values.php?startDate="+startDate+"&endDate="+endDate+"&type="+type,
			type: "POST",
			success:function(data){
				var jsonData=JSON.parse(data);
				$("#todaysalesValue").html(jsonData['salesTotal']);
				$("#todayappointmentValue").html(jsonData['appTotal']);
				$("#enquiryValue").html(jsonData['enquiryTotal']);
				$("#clientsValue").html(jsonData['clintsvisitTotal']);
				$('.divloader').fadeOut();
			},
			error:function (){}
		});
		
	}
	
	function infoWithFilter(startDate,endDate,type){
		
		$.ajax({
			url: "ajax/infoWithFilters.php?startDate="+startDate+"&endDate="+endDate+"&type="+type,
			type: "POST",
			success:function(data){
				$("#todaysalesDashboard").html(data);
			},
			error:function (){}
		});
	}
	
	
	/* initialize the calendar */
	
	$(function() {
		
		//####################Random color generator###########
		function getRandomColor() {
		    var colors = ['#FC3105','#BD2707','#F5A906','#35F506','#06F547','#06F59E','#06D8F5','#06B0F5','#0681F5','#0656F5','#0635F5','#0609F5','#4B06F5','#8106F5','#B406F5','#E706F5','#F506CD','#F50664','#F50647','#F5062A','#940000','#945100','#947E00','#5C9400','#229400','#00941D','#009469','#007594','#004F94','#002F94','#001694','#070094','#2B0094','#430094','#700094','#890094','#940090','#94006E','#940051','#940024','#940000','#A33E3E','#A34A3E','#FF0000','#FF4900','#FF7400','#FF9B00','#00FF36','#0070FF','#005DFF','#0032FF','#0C00FF','#4D00FF','#8000FF','#B600FF','#E400FF','#FF009E','#FF0055','#FF002E'];
		    return colors[Math.floor(Math.random() * colors.length)]
		} //####End####
		
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
		var calendarEl = document.getElementById('calendar');
		var calendar = new FullCalendar.Calendar(calendarEl, {
          schedulerLicenseKey: 'GPL-My-Project-Is-Open-Source',
          plugins: ['interaction','resourceTimeGrid','resourceDayGrid','timeGrid'],  
          defaultView: 'resourceTimeGridDay',
          eventClick: function(calEvent) {
          	appointment(calEvent.event.id,calEvent.event.groupId);
    	  },
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'resourceTimeGridDay,resourceTimeGridWeek,resourceDayGridMonth'
          },
          defaultDate: '2022-02-03',
          navLinks: true, // can click day/week names to navigate views
          editable: false,
          eventLimit: true, // allow "more" link when too many events
          nowIndicator: true,
          minTime: '10:00:00',
    	  maxTime: '20:00:00',
    //       minTime: '00:00:00',
    // 	  maxTime: '24:00:00',

          resources: [
    		{ id: '1', title: 'Test' },{ id: '2', title: 'Poonam' },{ id: '3', title: 'Riya' },{ id: '4', title: 'Rahul' },{ id: '5', title: 'RK' },{ id: '6', title: 'Neha' },{ id: '7', title: 'RASHMI' },    	  ],
                    events: [
            {
    					id: '1', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '1', 
    					title: 'Mrs.khan',
    					start: '2022-01-23 19:00:00',
    					end	: '2022-01-23 19:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '1', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '1', 
    					title: 'Mrs.khan',
    					start: '2022-01-23 19:00:00',
    					end	: '2022-01-23 19:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '2', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '2', 
    					title: 'Amir',
    					start: '2022-01-24 13:00:00',
    					end	: '2022-01-24 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '2', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '2', 
    					title: 'Amir',
    					start: '2022-01-24 13:00:00',
    					end	: '2022-01-24 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '3', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '3', 
    					title: 'Sonia',
    					start: '2022-01-24 15:00:00',
    					end	: '2022-01-24 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '3', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '3', 
    					title: 'Sonia',
    					start: '2022-01-24 15:00:00',
    					end	: '2022-01-24 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '5', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '4', 
    					title: 'Poonam',
    					start: '2022-01-24 17:30:00',
    					end	: '2022-01-24 18:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '5', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '4', 
    					title: 'Poonam',
    					start: '2022-01-24 17:30:00',
    					end	: '2022-01-24 18:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '6', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '5', 
    					title: 'Urvashi',
    					start: '2022-01-24 16:00:00',
    					end	: '2022-01-24 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '6', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '5', 
    					title: 'Urvashi',
    					start: '2022-01-24 16:00:00',
    					end	: '2022-01-24 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '7', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '5', 
    					title: 'Urvashi',
    					start: '2022-01-24 17:00:00',
    					end	: '2022-01-24 17:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '7', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '5', 
    					title: 'Urvashi',
    					start: '2022-01-24 17:00:00',
    					end	: '2022-01-24 17:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '8', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '6', 
    					title: 'Urvashi',
    					start: '2022-01-25 11:00:00',
    					end	: '2022-01-25 11:20:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '8', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '6', 
    					title: 'Urvashi',
    					start: '2022-01-25 11:00:00',
    					end	: '2022-01-25 11:20:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '9', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '6', 
    					title: 'Urvashi',
    					start: '2022-01-25 11:20:00',
    					end	: '2022-01-25 12:20:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '9', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '6', 
    					title: 'Urvashi',
    					start: '2022-01-25 11:20:00',
    					end	: '2022-01-25 12:20:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '58', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '39', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 17:00:00',
    					end	: '2022-01-31 17:40:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '58', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '39', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 17:00:00',
    					end	: '2022-01-31 17:40:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '64', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '44', 
    					title: 'Tracy',
    					start: '2022-02-02 16:00:00',
    					end	: '2022-02-02 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Avanzate Signature Massage',
    					},{
    					id: '64', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '44', 
    					title: 'Tracy',
    					start: '2022-02-02 16:00:00',
    					end	: '2022-02-02 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Avanzate Signature Massage',
    					},{
    					id: '65', 
    					resourceId: '1',
    					beautician: 'Test',
    					groupId: '44', 
    					title: 'Tracy',
    					start: '2022-02-02 17:00:00',
    					end	: '2022-02-02 17:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Cut & File',
    					},{
    					id: '65', 
    					resourceId: '',
    					beautician: 'Test',
    					groupId: '44', 
    					title: 'Tracy',
    					start: '2022-02-02 17:00:00',
    					end	: '2022-02-02 17:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Cut & File',
    					},{
    					id: '10', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '7', 
    					title: 'Rakesh',
    					start: '2022-01-24 15:00:00',
    					end	: '2022-01-24 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '10', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '7', 
    					title: 'Rakesh',
    					start: '2022-01-24 15:00:00',
    					end	: '2022-01-24 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '11', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '8', 
    					title: 'Omkar Singh',
    					start: '2022-01-25 10:40:00',
    					end	: '2022-01-25 11:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '11', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '8', 
    					title: 'Omkar Singh',
    					start: '2022-01-25 10:40:00',
    					end	: '2022-01-25 11:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '13', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '9', 
    					title: 'Reeva',
    					start: '2022-01-24 15:33:00',
    					end	: '2022-01-24 16:33:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '13', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '9', 
    					title: 'Reeva',
    					start: '2022-01-24 15:33:00',
    					end	: '2022-01-24 16:33:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '14', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '10', 
    					title: 'Sayli Mam',
    					start: '2022-01-25 14:00:00',
    					end	: '2022-01-25 14:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '14', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '10', 
    					title: 'Sayli Mam',
    					start: '2022-01-25 14:00:00',
    					end	: '2022-01-25 14:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '15', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '10', 
    					title: 'Sayli Mam',
    					start: '2022-01-25 14:20:00',
    					end	: '2022-01-25 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '15', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '10', 
    					title: 'Sayli Mam',
    					start: '2022-01-25 14:20:00',
    					end	: '2022-01-25 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '19', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '13', 
    					title: 'Urvashi',
    					start: '2022-01-27 12:00:00',
    					end	: '2022-01-27 13:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Skin Brightening Facial',
    					},{
    					id: '19', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '13', 
    					title: 'Urvashi',
    					start: '2022-01-27 12:00:00',
    					end	: '2022-01-27 13:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Skin Brightening Facial',
    					},{
    					id: '20', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '13', 
    					title: 'Urvashi',
    					start: '2022-01-27 13:30:00',
    					end	: '2022-01-27 13:50:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '20', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '13', 
    					title: 'Urvashi',
    					start: '2022-01-27 13:30:00',
    					end	: '2022-01-27 13:50:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '23', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 15:26:00',
    					end	: '2022-01-28 16:26:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '23', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 15:26:00',
    					end	: '2022-01-28 16:26:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '24', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 16:26:00',
    					end	: '2022-01-28 19:36:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '24', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 16:26:00',
    					end	: '2022-01-28 19:36:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '27', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '18', 
    					title: 'Mission',
    					start: '2022-01-28 10:00:00',
    					end	: '2022-01-28 10:40:00',
    					className : 'cancelled-appointment',
    					description: '',
    					service_name: 'Wash & Blast',
    					},{
    					id: '27', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '18', 
    					title: 'Mission',
    					start: '2022-01-28 10:00:00',
    					end	: '2022-01-28 10:40:00',
    					className : 'cancelled-appointment',
    					description: '',
    					service_name: 'Wash & Blast',
    					},{
    					id: '37', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '26', 
    					title: 'Urvashi',
    					start: '2022-01-29 11:00:00',
    					end	: '2022-01-29 12:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '37', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '26', 
    					title: 'Urvashi',
    					start: '2022-01-29 11:00:00',
    					end	: '2022-01-29 12:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '38', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '26', 
    					title: 'Urvashi',
    					start: '2022-01-29 12:00:00',
    					end	: '2022-01-29 12:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '38', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '26', 
    					title: 'Urvashi',
    					start: '2022-01-29 12:00:00',
    					end	: '2022-01-29 12:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '42', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '29', 
    					title: 'Jayesh',
    					start: '2022-01-31 14:10:00',
    					end	: '2022-01-31 14:30:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '42', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '29', 
    					title: 'Jayesh',
    					start: '2022-01-31 14:10:00',
    					end	: '2022-01-31 14:30:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '44', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '31', 
    					title: 'Rahul',
    					start: '2022-01-31 12:00:00',
    					end	: '2022-01-31 12:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '44', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '31', 
    					title: 'Rahul',
    					start: '2022-01-31 12:00:00',
    					end	: '2022-01-31 12:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '45', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '31', 
    					title: 'Rahul',
    					start: '2022-01-31 12:20:00',
    					end	: '2022-01-31 13:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '45', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '31', 
    					title: 'Rahul',
    					start: '2022-01-31 12:20:00',
    					end	: '2022-01-31 13:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '51', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 14:48:00',
    					end	: '2022-02-11 15:48:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Facial',
    					},{
    					id: '51', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 14:48:00',
    					end	: '2022-02-11 15:48:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Facial',
    					},{
    					id: '55', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '37', 
    					title: 'Urvashi',
    					start: '2022-01-31 17:00:00',
    					end	: '2022-01-31 18:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '55', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '37', 
    					title: 'Urvashi',
    					start: '2022-01-31 17:00:00',
    					end	: '2022-01-31 18:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '56', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '37', 
    					title: 'Urvashi',
    					start: '2022-01-31 18:00:00',
    					end	: '2022-01-31 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '56', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '37', 
    					title: 'Urvashi',
    					start: '2022-01-31 18:00:00',
    					end	: '2022-01-31 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '59', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '40', 
    					title: 'Urvashi',
    					start: '2022-02-01 12:30:00',
    					end	: '2022-02-01 13:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '59', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '40', 
    					title: 'Urvashi',
    					start: '2022-02-01 12:30:00',
    					end	: '2022-02-01 13:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '60', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '40', 
    					title: 'Urvashi',
    					start: '2022-02-01 13:30:00',
    					end	: '2022-02-01 13:50:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '60', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '40', 
    					title: 'Urvashi',
    					start: '2022-02-01 13:30:00',
    					end	: '2022-02-01 13:50:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '63', 
    					resourceId: '2',
    					beautician: 'Poonam',
    					groupId: '43', 
    					title: 'Tracy',
    					start: '2022-02-02 15:30:00',
    					end	: '2022-02-02 16:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Avanzate Signature Massage',
    					},{
    					id: '63', 
    					resourceId: '',
    					beautician: 'Poonam',
    					groupId: '43', 
    					title: 'Tracy',
    					start: '2022-02-02 15:30:00',
    					end	: '2022-02-02 16:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Avanzate Signature Massage',
    					},{
    					id: '16', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '11', 
    					title: 'Sandeep Kaur',
    					start: '2022-01-25 15:00:00',
    					end	: '2022-01-25 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '16', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '11', 
    					title: 'Sandeep Kaur',
    					start: '2022-01-25 15:00:00',
    					end	: '2022-01-25 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '17', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '12', 
    					title: 'Urvashi',
    					start: '2022-01-25 16:00:00',
    					end	: '2022-01-25 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '17', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '12', 
    					title: 'Urvashi',
    					start: '2022-01-25 16:00:00',
    					end	: '2022-01-25 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '18', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '12', 
    					title: 'Urvashi',
    					start: '2022-01-25 17:00:00',
    					end	: '2022-01-25 17:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '18', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '12', 
    					title: 'Urvashi',
    					start: '2022-01-25 17:00:00',
    					end	: '2022-01-25 17:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '21', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '14', 
    					title: 'Poonam',
    					start: '2022-01-27 13:00:00',
    					end	: '2022-01-27 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '21', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '14', 
    					title: 'Poonam',
    					start: '2022-01-27 13:00:00',
    					end	: '2022-01-27 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '29', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '20', 
    					title: 'Tbb Salon',
    					start: '2022-01-28 12:00:00',
    					end	: '2022-01-28 13:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '29', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '20', 
    					title: 'Tbb Salon',
    					start: '2022-01-28 12:00:00',
    					end	: '2022-01-28 13:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '34', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '24', 
    					title: 'Lucky',
    					start: '2022-01-28 18:00:00',
    					end	: '2022-01-28 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '34', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '24', 
    					title: 'Lucky',
    					start: '2022-01-28 18:00:00',
    					end	: '2022-01-28 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '35', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '25', 
    					title: 'Mrs.khan',
    					start: '2022-01-29 10:30:00',
    					end	: '2022-01-29 13:40:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '35', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '25', 
    					title: 'Mrs.khan',
    					start: '2022-01-29 10:30:00',
    					end	: '2022-01-29 13:40:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '36', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '25', 
    					title: 'Mrs.khan',
    					start: '2022-01-29 13:40:00',
    					end	: '2022-01-29 15:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Skin Brightening Facial',
    					},{
    					id: '36', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '25', 
    					title: 'Mrs.khan',
    					start: '2022-01-29 13:40:00',
    					end	: '2022-01-29 15:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Skin Brightening Facial',
    					},{
    					id: '43', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '30', 
    					title: 'Rahul',
    					start: '2022-01-31 12:00:00',
    					end	: '2022-01-31 12:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '43', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '30', 
    					title: 'Rahul',
    					start: '2022-01-31 12:00:00',
    					end	: '2022-01-31 12:20:00',
    					className : 'checkedin-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '46', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '32', 
    					title: 'Rashmeet',
    					start: '2022-01-31 13:00:00',
    					end	: '2022-01-31 13:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '46', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '32', 
    					title: 'Rashmeet',
    					start: '2022-01-31 13:00:00',
    					end	: '2022-01-31 13:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '57', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '38', 
    					title: 'Tanya',
    					start: '2022-01-31 17:30:00',
    					end	: '2022-01-31 19:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Whitening Treatment Facial',
    					},{
    					id: '57', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '38', 
    					title: 'Tanya',
    					start: '2022-01-31 17:30:00',
    					end	: '2022-01-31 19:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Whitening Treatment Facial',
    					},{
    					id: '66', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '45', 
    					title: 'Urvashi',
    					start: '2022-02-03 11:00:00',
    					end	: '2022-02-03 12:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '66', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '45', 
    					title: 'Urvashi',
    					start: '2022-02-03 11:00:00',
    					end	: '2022-02-03 12:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '67', 
    					resourceId: '3',
    					beautician: 'Riya',
    					groupId: '45', 
    					title: 'Urvashi',
    					start: '2022-02-03 12:00:00',
    					end	: '2022-02-03 12:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '67', 
    					resourceId: '',
    					beautician: 'Riya',
    					groupId: '45', 
    					title: 'Urvashi',
    					start: '2022-02-03 12:00:00',
    					end	: '2022-02-03 12:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '22', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '15', 
    					title: 'Mission',
    					start: '2022-01-27 16:00:00',
    					end	: '2022-01-27 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '22', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '15', 
    					title: 'Mission',
    					start: '2022-01-27 16:00:00',
    					end	: '2022-01-27 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '28', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '19', 
    					title: 'Puspa',
    					start: '2022-01-28 10:00:00',
    					end	: '2022-01-28 13:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '28', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '19', 
    					title: 'Puspa',
    					start: '2022-01-28 10:00:00',
    					end	: '2022-01-28 13:10:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '39', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '27', 
    					title: 'Hairport Salon',
    					start: '2022-01-29 13:00:00',
    					end	: '2022-01-29 13:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eye Treatment',
    					},{
    					id: '39', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '27', 
    					title: 'Hairport Salon',
    					start: '2022-01-29 13:00:00',
    					end	: '2022-01-29 13:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eye Treatment',
    					},{
    					id: '47', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '33', 
    					title: 'Urvashi',
    					start: '2022-01-31 13:00:00',
    					end	: '2022-01-31 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '47', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '33', 
    					title: 'Urvashi',
    					start: '2022-01-31 13:00:00',
    					end	: '2022-01-31 14:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '48', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '33', 
    					title: 'Urvashi',
    					start: '2022-01-31 14:00:00',
    					end	: '2022-01-31 14:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '48', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '33', 
    					title: 'Urvashi',
    					start: '2022-01-31 14:00:00',
    					end	: '2022-01-31 14:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '50', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 14:33:00',
    					end	: '2022-02-11 14:48:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Eyebrows',
    					},{
    					id: '50', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 14:33:00',
    					end	: '2022-02-11 14:48:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Eyebrows',
    					},{
    					id: '62', 
    					resourceId: '4',
    					beautician: 'Rahul',
    					groupId: '42', 
    					title: 'Poonam',
    					start: '2022-02-01 16:00:00',
    					end	: '2022-02-01 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '62', 
    					resourceId: '',
    					beautician: 'Rahul',
    					groupId: '42', 
    					title: 'Poonam',
    					start: '2022-02-01 16:00:00',
    					end	: '2022-02-01 17:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '24', 
    					resourceId: '5',
    					beautician: 'RK',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 16:26:00',
    					end	: '2022-01-28 19:36:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '24', 
    					resourceId: '',
    					beautician: 'RK',
    					groupId: '16', 
    					title: 'Muskaan Singla',
    					start: '2022-01-28 16:26:00',
    					end	: '2022-01-28 19:36:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Smothing',
    					},{
    					id: '31', 
    					resourceId: '5',
    					beautician: 'RK',
    					groupId: '22', 
    					title: 'Bhupesh',
    					start: '2022-01-28 13:30:00',
    					end	: '2022-01-28 14:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Advance Hair Cut',
    					},{
    					id: '31', 
    					resourceId: '',
    					beautician: 'RK',
    					groupId: '22', 
    					title: 'Bhupesh',
    					start: '2022-01-28 13:30:00',
    					end	: '2022-01-28 14:30:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Advance Hair Cut',
    					},{
    					id: '32', 
    					resourceId: '5',
    					beautician: 'RK',
    					groupId: '22', 
    					title: 'Bhupesh',
    					start: '2022-01-28 14:30:00',
    					end	: '2022-01-28 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Whitening Treatment Facial',
    					},{
    					id: '32', 
    					resourceId: '',
    					beautician: 'RK',
    					groupId: '22', 
    					title: 'Bhupesh',
    					start: '2022-01-28 14:30:00',
    					end	: '2022-01-28 16:00:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Whitening Treatment Facial',
    					},{
    					id: '25', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '17', 
    					title: 'Muskaan Singla',
    					start: '2022-01-27 17:30:00',
    					end	: '2022-01-27 18:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Sun Tan Facial',
    					},{
    					id: '25', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '17', 
    					title: 'Muskaan Singla',
    					start: '2022-01-27 17:30:00',
    					end	: '2022-01-27 18:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Sun Tan Facial',
    					},{
    					id: '26', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '17', 
    					title: 'Muskaan Singla',
    					start: '2022-01-27 18:15:00',
    					end	: '2022-01-27 18:35:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '26', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '17', 
    					title: 'Muskaan Singla',
    					start: '2022-01-27 18:15:00',
    					end	: '2022-01-27 18:35:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '30', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '21', 
    					title: 'Urvashi',
    					start: '2022-01-28 12:00:00',
    					end	: '2022-01-28 12:45:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Sun Tan Facial',
    					},{
    					id: '30', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '21', 
    					title: 'Urvashi',
    					start: '2022-01-28 12:00:00',
    					end	: '2022-01-28 12:45:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Sun Tan Facial',
    					},{
    					id: '33', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '23', 
    					title: 'Sonia',
    					start: '2022-01-28 15:00:00',
    					end	: '2022-01-28 16:00:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Full Back',
    					},{
    					id: '33', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '23', 
    					title: 'Sonia',
    					start: '2022-01-28 15:00:00',
    					end	: '2022-01-28 16:00:00',
    					className : 'pending-appointment',
    					description: '',
    					service_name: 'Full Back',
    					},{
    					id: '40', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '28', 
    					title: 'Urvashi',
    					start: '2022-01-29 18:00:00',
    					end	: '2022-01-29 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '40', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '28', 
    					title: 'Urvashi',
    					start: '2022-01-29 18:00:00',
    					end	: '2022-01-29 18:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '41', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '28', 
    					title: 'Urvashi',
    					start: '2022-01-29 18:20:00',
    					end	: '2022-01-29 19:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '41', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '28', 
    					title: 'Urvashi',
    					start: '2022-01-29 18:20:00',
    					end	: '2022-01-29 19:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Facial',
    					},{
    					id: '49', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '34', 
    					title: 'Poonam',
    					start: '2022-01-31 15:00:00',
    					end	: '2022-01-31 15:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '49', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '34', 
    					title: 'Poonam',
    					start: '2022-01-31 15:00:00',
    					end	: '2022-01-31 15:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '61', 
    					resourceId: '6',
    					beautician: 'Neha',
    					groupId: '41', 
    					title: 'Poonam',
    					start: '2022-02-01 14:00:00',
    					end	: '2022-02-01 14:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '61', 
    					resourceId: '',
    					beautician: 'Neha',
    					groupId: '41', 
    					title: 'Poonam',
    					start: '2022-02-01 14:00:00',
    					end	: '2022-02-01 14:15:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Eyebrows',
    					},{
    					id: '52', 
    					resourceId: '7',
    					beautician: 'RASHMI',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 15:48:00',
    					end	: '2022-02-11 18:58:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Hair Smothing',
    					},{
    					id: '52', 
    					resourceId: '',
    					beautician: 'RASHMI',
    					groupId: '35', 
    					title: 'Poonam',
    					start: '2022-02-11 15:48:00',
    					end	: '2022-02-11 18:58:00',
    					className : 'pending-appointment',
    					description: 'Tyryr T8768778798798',
    					service_name: 'Hair Smothing',
    					},{
    					id: '53', 
    					resourceId: '7',
    					beautician: 'RASHMI',
    					groupId: '36', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 15:00:00',
    					end	: '2022-01-31 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '53', 
    					resourceId: '',
    					beautician: 'RASHMI',
    					groupId: '36', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 15:00:00',
    					end	: '2022-01-31 15:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Hair Cut',
    					},{
    					id: '54', 
    					resourceId: '7',
    					beautician: 'RASHMI',
    					groupId: '36', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 15:20:00',
    					end	: '2022-01-31 16:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},{
    					id: '54', 
    					resourceId: '',
    					beautician: 'RASHMI',
    					groupId: '36', 
    					title: 'Muskaan Singla',
    					start: '2022-01-31 15:20:00',
    					end	: '2022-01-31 16:20:00',
    					className : 'billed-appointment',
    					description: '',
    					service_name: 'Pedicure',
    					},          ],
          eventRender: function(eventObj) {
			  var s = new Date(eventObj.event.start);
			  var e = new Date(eventObj.event.end);
    		  	$(eventObj.el).popover({
    	        content: "<p style=\"color:#2d2e59;\"><b style=\"color:#2d2e59;\"> Client Name: </b>&nbsp;"+eventObj.event.title+"&nbsp;<br><b style=\"color:#2d2e59;\"> Appointment Date: </b>"+s.getDate()+"-"+(s.getMonth()+1)+"-"+s.getFullYear()+"&nbsp;<br><b style=\"color:#2d2e59;\"> Provider Name: </b>"+eventObj.event.extendedProps.beautician+"&nbsp;<br><b style=\"color:#2d2e59;\"> Services: </b>"+eventObj.event.extendedProps.service_name+"&nbsp;<br><b style=\"color:#2d2e59;\"> Appointment Time: </b>"+s.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})+" To "+e.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})+"&nbsp;<br><b style=\"color:#2d2e59;\"> Notes: </b>"+eventObj.event.extendedProps.description+"&nbsp;<br></p>",
    	        // content: eventObj.event.extendedProps.description,
    	        html:true,
    	        trigger: 'hover',
    	        placement: 'top',
    	        container: 'body'
    	      });
			 
		    },
          selectAllow: function(select) {
              return moment().diff(select.start) <= 0
          },
          selectable: true,
          selectHelper: true,
          select: function (event) {
              var provider_id = event.resource.id;
              var start_time = event.startStr;
              start_time = start_time.split('T');
              var date = start_time[0];
              start_time = date+" "+start_time[1].split('+')[0];
              var end_time = event.endStr;
              end_time = end_time.split('T');
              end_time = date+" "+end_time[1].split('+')[0];
              var curr_time = '11:46:10';
              if(provider_id != ''){
                  $.ajax({
                    url: 'ajax/appointment_stafftime.php',
                    type: "POST",
        			data: {id : provider_id, date : date, time: curr_time, starttime : start_time, endtime : end_time},
        			dataType: 'json',
    			    beforeSend : function(){
        			    $('.loader-gif').show();
        			},
        			success: function(response) {
        				var ds = response;
        				if(ds['success']=='0'){
                            $('.staff').html('<option value="">--Select--</option><option selected value="'+ds['data']['pid']+'">'+ds['data']['pname']+'</option>');
                            $('.start_time').val(ds['data']['start']);
    						$('#book_appointment_modal').modal('show');
    						$('#date').val(date);
    						$('#time').val(ds['data']['start']);
    						$('.loader-gif').hide();
    					} else if(ds['success']=='1'){
    						toastr.error(ds['data']['spcat']+' Unavailable.');
    						calendar.render();
    						set_calendar_width();
    						$('.loader-gif').hide();
    					} else if(ds['success']=='2'){
    						toastr.error(ds['data']['spcat']+' Unavailable.');
    						calendar.render();
    						set_calendar_width();
    						$('.loader-gif').hide();
    					}
        			}
                  });
              }
          },
        });
    
        calendar.render();
        $('.fc-content-skeleton').prepend('<div class="calander-blank"></div>');
	});	
	
	function autocomplete_serr(){
		$(".ser").autocomplete({ 
			source: function(request, response) {
				var ser_stime = '';
				if($(this.element).parent().parent().parent().parent().parent().parent().attr('id')=='TextBoxContainer'){
					ser_stime = $('#date').val()+' '+$('#time').val();
					}else{
					ser_stime = $(this.element).parent().parent().parent().parent().parent().parent().prev('tr').find('.ser_etime').val();
				}
				$.getJSON("ajax/bill.php", { term: request.term,ser_cat_id: $(this.element).parent().parent().find('.ser_cat_id').val(),ser_stime:ser_stime,page_info:'app' }, response);
			},
			minLength: 1,
			select:function (event, ui) { 
				var appo_time = $('#time').val();
				var appo_date = $('#date').val();
				if(appo_time == ''){
					$('#time').addClass('invalid');
				} else if(appo_date == ''){
					$('#date').addClass('invalid');
					$('#time').removeClass('invalid');
				} else{
				
					$('#date').removeClass('invalid');
					var etime = Date.parse('20 Aug 2000 '+$('#close_time').val());
					var setime = Date.parse('20 Aug 2000 '+ui.item.ser_etime.split(' ')[1]+':00');
					var et_status = '0'; // Extra time status
					if(setime > etime && et_status == '0'){	
						// var row = $(this).parent().parent().parent().parent().parent().parent();
						var row = $(this).parent().parent();
						row.find('input[type="text"].ser').val('');
						row.find('.serr').val('');
						// row.find('.pa_ser').val('');
						row.find('.prr').val('');
						row.find('.qt').val('0');
						row.find('.disc_row ').val('0');
						row.find('.duration').val('');
						row.find('.ser_stime').val('');
						row.find('.ser_etime').val('');
						row.find('.start_time').val(('').substring(11));
						row.find('.end_time').val(('').substring(11));
			
						toastr.error('Appointment can\'t book for this service. salon will close at '+onTimeChange($('#close_time').val()));
					} else {
						// var row = $(this).parent().parent().parent().parent().parent().parent();
						var row = $(this).parent().parent();
						row.find('.serr').val(ui.item.id);
						row.find('.prr').val(ui.item.price);
						row.find('.qt').val('1');
						row.find('.disc_row ').val('0');
						row.find('.duration').val(ui.item.duration);
						row.find('.ser_stime').val(ui.item.ser_stime);
						row.find('.ser_etime').val(ui.item.ser_etime);
						row.find('.start_time').val(onTimeChange((ui.item.ser_stime).substring(11)));
						row.find('.end_time').val(onTimeChange((ui.item.ser_etime).substring(11)));
						appointmenttime();
						var clientId = $('#clientid').val();
			
						price_calculate(row);
						sumup();
						// paymode($('.act').val());
					}
				}
			}
		});	
	}
	
	function appointmenttime(){
		
		var start_arr=[];	
		var end_arr  =[];
		var e=$('.TextBoxContainer');
		// e.find('.staff option[value=""]').prop('selected',true); 
		
		var date=$('#date').val();
		var duration = parseInt(e.find('.duration').val()); //duration
		
		var ser_stime=$('#time').val();

		e.find('.ser_stime').val(date+" "+time12to24(ser_stime));
		e.find('.start_time').val(ser_stime);
		
		var ser_stime1=e.find('.ser_stime').val();
		var da = new Date(ser_stime1.replace(/-/g, '/'));
		
		var new_endtime= new Date(da.getTime() + (duration * 60 * 1000));
		
		var final_atime=new_endtime.getFullYear() + '-' +('0' + (new_endtime.getMonth()+1)).slice(-2)+ '-' +  addZero(new_endtime.getDate()) + ' '+addZero(new_endtime.getHours())+ ':'+('00' + (new_endtime.getMinutes())).slice(-2)+ ':'+new_endtime.getSeconds()+'0';
		
		e.find('.ser_etime').val(final_atime);
		e.find('.end_time').val(onTimeChange(final_atime.substr(11)));
		
		var start = e.nextAll('tr').find('.ser_etime').length;
		var index_value=$('.TextBoxContainer').index();
		
		for(var i=0;i<start;i++){ 
			
			var prev_start_time = $(".ser_stime:eq("+(i+index_value)+")").val();
			
			var prev_stime = new Date(prev_start_time.replace(/-/g, '/'));
			var prev_duration = $('.duration:eq('+(i+index_value)+')').val(); //prev_duration
			
			var prev_starttime= new Date(prev_stime.getTime() + (prev_duration * 60 * 1000));
			
			var final_atime=prev_starttime.getFullYear() + '-' +('0' + (prev_starttime.getMonth()+1)).slice(-2)+ '-' +  addZero(prev_starttime.getDate()) + ' '+addZero(prev_starttime.getHours())+ ':'+('00' + (prev_starttime.getMinutes())).slice(-2)+ ':'+prev_starttime.getSeconds()+'0';
			
			var next_start_time = $(".ser_etime:eq("+(i+index_value)+")").val(); 
			
			var next_stime = new Date(next_start_time.replace(/-/g, '/'));
			var next_duration = $('.duration:eq('+(i+index_value+1)+')').val(); //next_duration
			var next_starttime= new Date(next_stime.getTime() + (next_duration * 60 * 1000));
			
			var final_etime=next_starttime.getFullYear() + '-' +('0' + (next_starttime.getMonth()+1)).slice(-2)+ '-' +  addZero(next_starttime.getDate()) + ' '+addZero(next_starttime.getHours())+ ':'+('00' + (next_starttime.getMinutes())).slice(-2)+ ':'+next_starttime.getSeconds()+'0';
			
			start_arr.push(final_atime);
			end_arr.push(final_etime);  
			
			$(".end_time:eq("+(i+index_value+1)+")").val(onTimeChange((end_arr[i]).substring(11))); 
			$(".ser_etime:eq("+(i+index_value+1)+")").val(end_arr[i]); 
			$(".start_time:eq("+(i+index_value+1)+")").val(onTimeChange((start_arr[i]).substring(11))); 
			$(".ser_stime:eq("+(i+index_value+1)+")").val(start_arr[i]); 
		}
	}
	
	function check() {
		$client_id = $('#clientid').val();				
		jQuery.ajax({
			url: "checkccont.php?p="+$("#cont").val(),
			type: "POST",
			success:function(data){
				
				if(data == '1'){
					if($client_id == ''){
						$("#client-status").html("Contact number already exists");
						$('#cont').val("");
						$('#dob').val("");
						$('#aniv').val("");
					}
				}else{
					$("#client-status").html("");
					$("#clientid").val("");
					$('#dob').val("");
					$('#aniv').val("");
				}
			},
			error:function (){}
		});
	}
	
	function servicestarttime(time, current){
		var e = current;
		var date = $('#date').val();
		if(date != ''){
			$('#date').removeClass('invalid');
			$.ajax({  
	        url:"ajax/system_details.php",
	        method:"POST",
	        dataType: "json",
	        data: {date : date, 'action':'checkapptime'},
	        success:function(response){
	        	
	            	if(response.status == '1'){
	            		sstime = response.starttime;
	            		eetime = response.endtime;
	               		var stime = Date.parse('20 Aug 2000 '+sstime);
						var etime = Date.parse('20 Aug 2000 '+eetime);
						var cpmtime = Date.parse('20 Aug 2000 '+time+':00');
						if(stime == '' || etime == ''){
							
						} else {
							if(cpmtime < stime || cpmtime > etime){
								e.parents('tr').find('.start_time').val('');
								e.parents('tr').find('.ser_etime').val('');
								e.parents('tr').find('.end_time').val('');
							} else {
								
							var start_arr=[];	
							var end_arr  =[];
							
							e.parents('tr').find('.staff option[value=""]').prop('selected',true); 
							
							var date=$('#date').val();
							var duration = parseInt(e.parents('tr').find('.duration').val()); //duration
							var ser_stime=e.parents('tr').find('.start_time').val();
							
							e.parents('tr').find('.ser_stime').val(date+" "+time12to24(ser_stime));
							
							var ser_stime1=e.parents('tr').find('.ser_stime').val();
							var da = new Date(ser_stime1.replace(/-/g, '/'));
							
							var new_endtime= new Date(da.getTime() + (duration * 60 * 1000));
							if(!isNaN(duration)){
								var final_atime=new_endtime.getFullYear() + '-' +('0' + (new_endtime.getMonth()+1)).slice(-2)+ '-' +  addZero(new_endtime.getDate()) + ' '+(new_endtime.getHours()<10?'0':'')+new_endtime.getHours()+ ':'+(new_endtime.getMinutes()<10?'0':'')+new_endtime.getMinutes()+ ':'+new_endtime.getSeconds()+'0';
							} else {
								var final_atime = '2000-08-20'+' '+time12to24(ser_stime);
							}
							
							
							e.parents('tr').find('.ser_etime').val(final_atime);
							e.parents('tr').find('.end_time').val(onTimeChange(final_atime.substr(11)));
							
							var start = e.parents('tr').nextAll('tr').find('.ser_etime').length;
							
							var index_value=e.parents('.TextBoxContainer').index();
							
							
							for(var i=0;i<start;i++){ 
								$(".staff option[value='']:eq("+(i+index_value+1)+")").prop('selected',true);
								
								var prev_start_time = $(".ser_stime:eq("+(i+index_value)+")").val();
								var prev_stime = new Date(prev_start_time.replace(/-/g, '/'));
								var prev_duration = $('.duration:eq('+(i+index_value)+')').val(); //prev_duration
								
								
								var prev_starttime= new Date(prev_stime.getTime() + (prev_duration * 60 * 1000));
								var final_atime=prev_starttime.getFullYear() + '-' +('0' + (prev_starttime.getMonth()+1)).slice(-2)+ '-' +  addZero(prev_starttime.getDate()) + ' '+addZero(prev_starttime.getHours())+ ':'+('00' + (prev_starttime.getMinutes())).slice(-2)+ ':'+prev_starttime.getSeconds()+'0';
								
								var next_start_time = $(".ser_stime:eq("+(i+index_value+1)+")").val(); 
								var next_stime = new Date(next_start_time.replace(/-/g, '/'));
								var next_duration = $('.duration:eq('+(i+index_value+1)+')').val(); //next_duration
								var next_starttime= new Date(next_stime.getTime() + (next_duration * 60 * 1000));
								var final_etime=next_starttime.getFullYear() + '-' +('0' + (next_starttime.getMonth()+1)).slice(-2)+ '-' +  addZero(next_starttime.getDate()) + ' '+time12to24(addZero(next_starttime.getHours())+ ':'+('00' + (next_starttime.getMinutes())).slice(-2)+ ':'+next_starttime.getSeconds());
								
								start_arr.push(final_atime);
								end_arr.push(final_etime);  
								
								$(".end_time:eq("+(i+index_value+1)+")").val((end_arr[i]).substring(11)); 
								$(".ser_etime:eq("+(i+index_value+1)+")").val(end_arr[i]); 
								$(".start_time:eq("+(i+index_value+1)+")").val((start_arr[i]).substring(11)); 
								$(".ser_stime:eq("+(i+index_value+1)+")").val(start_arr[i]); 
							}
							}
						}
	               	} else {
	               		current.val('');
	               	}
	            }
	       	});
		} else {
			current.val('');
			$('#date').addClass('invalid');
		}
		
	}
	
	function addZero(i) {
		if (i < 10) {
			i = "0" + i;
		}
		return i;
	}
	
	function price_calculate(row){
		var pr = row.find('.prr').val();
		var qt = row.find('.qt').val();
		var sum = pr * 1;
		row.find('.price').val(sum);
		var pric = 0;
		var sums = 0;
		var sump = 0;
		var sumt = 0;
		var sum  = 0;
		var ids  = $(".serr");
		
		
		var inputs = $(".price");
		for(var i = 0; i < inputs.length; i++){
			var service = $(ids[i]).val().split(',');
			if(service[0]=="sr"){
				sums = sums + parseFloat($(inputs[i]).val());
			}
			else if(service[0]=="pr"){
				sump = sump + parseFloat($(inputs[i]).val());
			}
			sum = parseFloat(sum) + parseFloat($(inputs[i]).val());
			$("#sum").html("Rs. "+sum.toFixed(2));
		}	
	}
	
	function sumup(){
    	var pric = 0;
    	var sums = 0;
    	var sump = 0;
    	var sumt = 0;
    	var sum = 0;
    	var ids = $(".serr");
    	
    	var inputs = $(".price");
    	for(var i = 0; i < inputs.length; i++){
    		var service = $(ids[i]).val().split(',');
    		if(service[0]=="sr"){
    			sums = sums + parseFloat($(inputs[i]).val());
    		}
    		else if(service[0]=="pr"){
    			sump = sump + parseFloat($(inputs[i]).val());
    		}
    		sum = parseFloat(sum) + parseFloat($(inputs[i]).val());
    		sum = sum || 0;

    		$("#total").val(sum);
    		$(".total-amount span").text(sum);
    	}
    }
    
    /* time changing function*/
	function change_timing(e){
		var start_arr=[];	
		var end_arr  =[];

		var ser_stime = e.parents('tr').find('.ser_stime').val(); //start time
		var ser_etime = e.parents('tr').find('.ser_etime').val(); //end time
		var d2 = new Date(ser_stime.replace(/-/g, '/'));
		var d1 = new Date(ser_etime.replace(/-/g, '/'));
		var diff_minutes =  (d1- d2);
		
		var start = e.parents('tr').prevAll('tr').find('.ser_etime').length;
		var count = e.parents('tr').nextAll('tr').find('.ser_etime').length;
		var p_service = e.parents('tr').find('.pa_ser').val();
		if(p_service != ''){
			e.parents('tr').hide();
		} else {
			e.parents('tr').remove();
		}
		 
		
		var add_in_start  = $(".ser_etime:eq("+(start-1)+")").val();
		start_arr.push(add_in_start);
		
		
		for(var i=0;i<count;i++){	
			var add_in_end = $(".ser_etime:eq("+(i+start)+")").val();
			var add_in_start1  = $(".ser_stime:eq("+(i+start)+")").val();
			var d2 = new Date(add_in_end.replace(/-/g, '/'));
			var new_endtime= (new Date(d2 - diff_minutes));
			
			var final_etime=new_endtime.getFullYear() + '-' +('0' + (new_endtime.getMonth()+1)).slice(-2)+ '-' +  addZero(new_endtime.getDate()) + ' '+addZero(new_endtime.getHours())+ ':'+('00' + (new_endtime.getMinutes())).slice(-2)+ ':'+new_endtime.getSeconds()+'0';
			
			end_arr.push(final_etime);
			start_arr.push(final_etime); 
			$(".end_time:eq("+(i+start)+")").val((end_arr[i]).substring(11)); 
			$(".ser_etime:eq("+(i+start)+")").val(end_arr[i]); 
			$(".start_time:eq("+(i+start)+")").val((start_arr[i]).substring(11)); 
			$(".ser_stime:eq("+(i+start)+")").val(start_arr[i]);  
			
		}
		
	}
	
	function increment_ids(){
		var row_len=$('.TextBoxContainer');
		var i=0;
		row_len.each(function(){
			var a=$(this).find('.staff').attr('name','staffid'+i+'[]');
			i++; 
		});
	}
    
	
	var json_values = [];
	
	
	function sendaniv() {
		json_values = [];
		var count = $('input.ann:checked').length;
		if(count>0){
			$(".ann").each(function()
            {
				if($(this).is(':checked'))
                {
                    json_values.push({name: $(this).data("name"),contact: $(this).data("contact") });
				}
			});
			$('#myModal').modal('show');
			}else{
            alert('Please Select at least one Client'); 
		}
	}
	
	function sendbday() {
		json_values = [];
		var count = $('input.bday:checked').length;
		if(count>0){
			$(".bday").each(function()
            {
				if($(this).is(':checked'))
                {
                    json_values.push({name: $(this).data("name"),contact: $(this).data("contact") });
				}
			});
			$('#myModal').modal('show');
			}else{
            alert('Please Select at least one Client'); 
		}
	}
	
	function sendmessage() {
		var message = $('#message').val();
		$.ajax({
			type: "POST",
			url: 'ajax/sendsms.php',
			data: {
				json: JSON.stringify(json_values,true),
				message: message,
			},
			dataType: 'text',
			success: function(result) {
				toastr.success(result);
				$('#message').val('Hello {name}\nFrom {Salon}');
				$("input[type='checkbox']").attr("checked",false);
			}
		});
	}
	
	var table_print,table_print1,table_print2,table_print3;
	$(document).ready(function() {
	    
	    $("#btnAdd").bind("click", function() {
    		var empty_fields = [];
    		$('.ser').each(function(){
    			if($(this).val() == ''){
    				empty_fields.push('empty_field');
    			}
    		});
    		$('.start_time').each(function(){
    			if($(this).val() == ''){
    				empty_fields.push('empty_field');
    			}
    		});
    		$('.end_time').each(function(){
    			if($(this).val() == ''){
    				empty_fields.push('empty_field');
    			}
    		});
    		$('.price').each(function(){
    			if($(this).val() == ''){
    				empty_fields.push('empty_field');
    			}
    		});
    		$('.staff option:selected').each(function(){
    			if($(this).val() == ''){
    				empty_fields.push('empty_field');
    			}
    		});
    		if(empty_fields && empty_fields.length == 0){
    			var clonetr = $("#TextBoxContainer").clone().addClass('TextBoxContainer');
    			clonetr.removeAttr('id');
    			clonetr.find("table.add_row").remove();
    			clonetr.find('.sno').html('<span class="remm icon-trash2 " style="color:red;" onclick="change_timing($(this));sumup();"></span>');
    			clonetr.find('input').val('');
    			$("#addBefore").before(clonetr);
    			clonetr.find('.staff option[value=""]').prop('selected',true);
    			increment_ids();
    			formValidaiorns();
    			$(".time").datetimepicker({
    		        format: "HH:ii P",
    		        showMeridian: true,
    		        autoclose: true,
    		        pickDate: false,
    		        startView: 1,
    	    		maxView: 1
    		    });
    		    $(".datetimepicker").find('thead th').remove();
    	  		$(".datetimepicker").find('thead').append($('<th class="switch text-warning">').html('Pick Time'));
    	  		$(".datetimepicker").find('tbody').addClass('alltimes');
    	  		$('.switch').css('width','190px');
    
    			$('.ser').on('click',function(){
    				$(this).keydown();
    			});
    
    			$('.ser').on('keyup',function(){
    				if($(this).val().length > 0){
    					autocomplete_serr();
    				}
    			});
    		}
    	});
    	
	
		table_print1 = $('.tableprint1').DataTable( {
			dom: 'Bfrtip',
			"aaSorting":[],
			buttons: [	{
				extend: 'excelHtml5',
				text: '<i class="fa fa-file-excel-o"></i> Excel',
				titleAttr: 'Export to Excel',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'csvHtml5',
				text: '<i class="fa fa-file-text-o"></i> CSV',
				titleAttr: 'CSV',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'print',
				exportOptions: {
					columns: ':visible'
				},
				customize: function(win) {
					$(win.document.body).find( 'table' ).find('td:last-child, th:last-child').remove();
				}
			},
			],
			"fnDrawCallback": function (oSettings) {
				$("#smstab_wrapper").find('.pagination').append('<li class="paginate_button"><button class="btn-info" style="float : right;" id="chkk2_sms">Send SMS</button></li>');
			},
		} );
		$("#chkk2_sms").on('click',function(){
			json_values = [];
			var inc = 0;
			
			table_print1.rows().every( function ( rowIdx, tableLoop, rowLoop ) {
				var data = this.data();
				
				var row = table_print1.rows(rowIdx);
				var data1 = row.nodes();
				var contact_node = $(data1).find(".chkk2");
				if($(contact_node).prop("checked") == true){
					inc++;
					json_values.push({name: $(contact_node).data("name"),contact: $(contact_node).data("contact") });
				}
				
			} );
			if(inc>0){
				$('#myModal').modal('show');
				
				}else{
				alert('Please Select at least one client'); 
			}
		});
		var rows = table_print1.rows({ 'search': 'applied' }).nodes();
		
		$("#iregchk").click(function () {
			if($(this).prop("checked") == true){
				$('.chkk2', rows).prop('checked', true);
			}
			else if($(this).prop("checked") == false){
				$('.chkk2', rows).prop('checked', false);
			}
		});
	} );
	
	$(document).ready(function() {
	    
	   // client auto-complete
	    
	    $(".client").autocomplete({
            source: "autocomplete/client.php",
            minLength: 1,
            select: function(event, ui) {
                event.preventDefault();
                $('#client').val(ui.item.name);
                $('#clientid').val(ui.item.id); 
                $('#client_branch_id').val(ui.item.client_branch_id); 
                $('#cont').val(ui.item.cont);
                $('#gender #gn-'+ui.item.gender).attr('selected', true);
        	}				
    	});
	
		table_print2 = $('.tableprint3').DataTable( {
			dom: 'Bfrtip',
			"ordering": false,
			"aaSorting":[],
			buttons: [	{
				extend: 'excelHtml5',
				text: '<i class="fa fa-file-excel-o"></i> Excel',
				titleAttr: 'Export to Excel',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'csvHtml5',
				text: '<i class="fa fa-file-text-o"></i> CSV',
				titleAttr: 'CSV',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'print',
				exportOptions: {
					columns: ':visible'
				},
				customize: function(win) {
					$(win.document.body).find( 'table' ).find('td:last-child, th:last-child').remove();
				}
			},
			],
			"fnDrawCallback": function (oSettings) {
				$("#smstab2_wrapper").find('.pagination').append('<li class="paginate_button"><button class="btn-info" style="float : right;" id="chkk_sms">Send SMS</button></li>');
			},
		} );
		$("#chkk_sms").on('click',function(){
			json_values = [];
			var inc = 0;
			
			table_print2.rows().every( function ( rowIdx, tableLoop, rowLoop ) {
				var data = this.data();
				
				var row = table_print2.rows(rowIdx);
				var data1 = row.nodes();
				var contact_node = $(data1).find(".chkk");
				if($(contact_node).prop("checked") == true){
					inc++;
					json_values.push({name: $(contact_node).data("name"),contact: $(contact_node).data("contact") });
				}
				
			} );
			if(inc>0){
				$('#myModal').modal('show');
				
				}else{
				alert('Please Select at least one client'); 
			}
		});
		var rows = table_print2.rows({ 'search': 'applied' }).nodes();
		
		$("#enqchk").click(function () {
			if($(this).prop("checked") == true){
				$('.chkk', rows).prop('checked', true);
			}
			else if($(this).prop("checked") == false){
				$('.chkk', rows).prop('checked', false);
			}
		});
	} );
	
	$(document).ready(function() {
	    formValidaiorns();
		table_print3 = $('.tableprint4').DataTable( {
			dom: 'Bfrtip',
			"aaSorting":[],
			buttons: [	{
				extend: 'excelHtml5',
				text: '<i class="fa fa-file-excel-o"></i> Excel',
				titleAttr: 'Export to Excel',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'csvHtml5',
				text: '<i class="fa fa-file-text-o"></i> CSV',
				titleAttr: 'CSV',
				title: 'AK Unisex salon',
				exportOptions: {
					columns: ':not(:last-child)',
				}
			},
			{
				extend: 'print',
				exportOptions: {
					columns: ':visible'
				},
				customize: function(win) {
					$(win.document.body).find( 'table' ).find('td:last-child, th:last-child').remove();
				}
			},
			],
			"fnDrawCallback": function (oSettings) {
				$("#smstab3_wrapper").find('.pagination').append('<li class="paginate_button"><button class="btn-info" style="float : right;"  id="chkk3_sms">Send SMS</button></li>');
			},
		} );
		$("#chkk3_sms").on('click',function(){
			json_values = [];
			var inc = 0;
			
			table_print3.rows().every( function ( rowIdx, tableLoop, rowLoop ) {
				var data = this.data();
				
				var row = table_print3.rows(rowIdx);
				var data1 = row.nodes();
				var contact_node = $(data1).find(".chkk3");
				if($(contact_node).prop("checked") == true){
					inc++;
					json_values.push({name: $(contact_node).data("name"),contact: $(contact_node).data("contact") });
				}
				
			} );
			if(inc>0){
				$('#myModal').modal('show');
				
				}else{
				alert('Please Select at least one client'); 
			}
		});
		var rows = table_print3.rows({ 'search': 'applied' }).nodes();
		
		$("#regchk").click(function () {
			if($(this).prop("checked") == true){
				$('.chkk3', rows).prop('checked', true);
			}
			else if($(this).prop("checked") == false){
				$('.chkk3', rows).prop('checked', false);
			}
		});
		
		set_calendar_width();
	} );
	
	function set_calendar_width(){	
		
			var no_of_providers = "7";	
			if(no_of_providers>4){	
		
				var table_width = 1000;	
				var extra_width = (no_of_providers-4)*100;	
				table_width += extra_width;	
				$(".fc-view").find("table").width(table_width);	
			}	
		
			$(".fc-resourceTimeGridDay-button,.fc-resourceTimeGridWeek-button,.fc-resourceDayGridMonth-button").click(function(){	
				if(no_of_providers>4){	
		
					var table_width = 1000;	
					var extra_width = (no_of_providers-4)*100;	
					table_width += extra_width;	
					$(".fc-view").find("table").width(table_width);	
				}	
			});	
		}
	
	
	function sendsms(cls){
		json_values = [];
		var inc = 0;
		
		table_print.rows().every( function ( rowIdx, tableLoop, rowLoop ) {
			var data = this.data();
			
			var row = table_print.rows(rowIdx);
			var data1 = row.nodes();
			var contact_node = $(data1).find(cls);
			if($(contact_node).prop("checked") == true){
				inc++;
				json_values.push({name: $(contact_node).data("name"),contact: $(contact_node).data("contact") });
			}
			
		} );
		if(inc>0){
			$('#myModal').modal('show');
			
			}else{
			alert('Please Select at least one client'); 
		}
	}
	
    $(function () {
		
		$(".event-tag span").click(function () {
			$(".event-tag span").removeClass("selected");
			$(this).addClass("selected");
		});
		
		$(document).on('click', '.remove-event', function (e) {
			$(this).parent().remove();
		});
		
		
		/* initialize the external events */
		
		$('#external-events .fc-event').each(function () {
			
			// store data so the calendar knows to render an event upon drop
			$(this).data('eventObject', {
				title: $.trim($(this).text()),
				className: $(this).attr("data-bg"), // use the element's text as the event title
				stick: true // maintain when user navigates (see docs on the renderEvent method)
			});
			
			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true, // will cause the event to go back to its
				revertDuration: 0 //  original position after the drag
			});
			
		});
		
		
		
		
		
		/*Add new event*/
		// Form to add new event
		
		$("#createEvent").on('submit', function (ev) {
			ev.preventDefault();
			
			var $event = $(this).find('.new-event-form'),
			event_name = $event.val(),
			tagColor = $('.event-tag  span.selected').attr('data-tag');
			
			if (event_name.length >= 3) {
				
				var newid = "new" + "" + Math.random().toString(36).substring(7);
				// Create Event Entry
				$("#external-events .checkbox").before(
				'<div id="' + newid + '" class="fc-event ' + tagColor + '" data-bg="' + tagColor + '">' + event_name + '<span class="fa fa-close remove-event"></span></div>'
				);
				
				
				var eventObject = {
					title: $.trim($("#" + newid).text()),
					className: $("#" + newid).attr("data-bg"), // use the element's text as the event title
					stick: true
				};
				
				// store the Event Object in the DOM element so we can get to it later
				$("#" + newid).data('eventObject', eventObject);
				
				// Reset draggable
				$("#" + newid).draggable({
					revert: true,
					revertDuration: 0,
					zIndex: 999
				});
				
				// Reset input
				$event.val('').focus();
				} else {
				$event.focus();
			}
		});
	});
	
	$(document).on("change", '.staff', function() {
		
					var app_eid  = 0;
		
		
		staff = $(this).val();
		var durr  		= $(this).parent().parent().find('.durr').val();
		var starttime   = $(this).parents('tr').find('.ser_stime').val();
		var endtime     = $(this).parents('tr').find('.ser_etime').val();
		var select_staff= $(this).parents('tr').find('.staff option[value=""]');	
		
		date = $('#date').val();
		time = $('#time').val();
		var durr_plus = 0;
		var prev_rows = $(this).parent().parent().prevAll('tr');
        $(this).parent().parent().prevAll('tr').each(function(){
            durr_plus += parseInt($(this).find('.durr').val());
		});
		if(starttime !=''){
			$.ajax({
				url: "ajax/appointment_stafftime.php?id="+staff+"&date="+date+"&time="+time+"&starttime="+starttime+"&endtime="+endtime+"&app_eid="+app_eid,
				type: "POST",
				success:function(data){
		
					var durr_count = 0;
					var ds = JSON.parse(data.trim());
					starttime = ds['start'];
					endtime = ds['end'];
					var ds = JSON.parse(data.trim());
					if(ds['success']=='0'){
						toastr.success(ds['data']['spcat']+' Available.');
						}else if(ds['success']=='1'){
						toastr.error(ds['data']['spcat']+' Unavailable.');
						select_staff.prop("selected",true);
						showmodal(date,staff);
						}else if(ds['success']=='2'){
						toastr.error(ds['data']['spcat']+' Unavailable.');
						select_staff.prop("selected",true);
					}
				},
				error:function (){}
			});
			}else{
			select_staff.prop('selected',true);
		}
	});
	
	
	function appointment(inv,inv_id){
		var row = $("#modal-body");
		row.find('.name').html('loading...');
		row.find('.service').html('loading...');
		row.find('.staff').html('loading...');
		$("#appointment_modal").modal('show');
		$.ajax({
			url: "ajax/invoice.php",
			data :{inv:inv_id, aii : inv},
			type: "POST",
			success:function(data){
				var row = $("#modal-body");
				var ds = JSON.parse(data.trim());
				row.find('.name').html(ds['client']);
				row.find('.service').html(ds['service']);
				row.find('.staff').html(ds['beautician']);
				row.find('.spnotes').html(ds['notes']);
				row.find('.apdate').html(ds['date']);
				row.find('.aptime').html(ds['start_time']+' To '+ds['end_time']);
				row.find('#checkin_app_id').val(inv_id);
				if(ds['checkin_status'] == 1){
				    $('#checkin').hide();
				    $('#checkin_time').remove();
				    $('#modal-body tbody').append('<tr id="checkin_time"><th>Check In Time</th><td>'+ds['checkin_time']+'</td></tr>');
				} else {
				    $('#checkin').show();
				    $('#checkin_time').remove();
				}
				if(ds['bill_status'] == '1'){
				    $('#but').hide();
				    $('#bill_cancel').hide();
				    $('#checkin').hide();
				    // $('#bill').show();
				} else if(ds['appointment_status'] == 'Cancelled'){
				    $('#bill_cancel').show();
				    $('#but').hide();
				    $('#checkin').hide();
				} else {
				    // $('#bill').hide();
				    $('#but').show();$('#bill_cancel').hide();
				    $('#edit_md_btn').attr('href',"appointment.php?id="+inv_id);
				    $('#conv_md_btn').attr('href',"billing.php?bid="+inv_id);
				}
			},
			error:function (){},
		});
	}
	
	function appointmentedit(inv){
		
		$("#but").html('loading...');
		jQuery.ajax({
			url: "ajax/invbuttons.php?inv="+inv,
			type: "POST",
			success:function(data){
				$("#but").html(data);
			},
			error:function (){}
		});
	}
	
	function markCheckIn(){
        var app_id = $('#checkin_app_id').val();
        $.ajax({
            url : 'ajax/appointment_stafftime.php',
            type : 'POST',
            data : {action : 'mark_checkin', app_id : app_id},
            dataType : 'JSON',
            success : function(res){
                if(res.status == 1){
                    alert('Checked in successfully.');
                    window.location.reload();
                } else {
                    alert('Error occured, please try again.');
                }
            }
        });
	}
	
</script>


<!-- Modal -->
<div class="modal fade" id="appointment_modal" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h4 class="modal-title">Appointment Details</h4>
			</div>
			<div class="modal-body table-responsive" id="modal-body">
				<table class="table table-bordered">
					<tbody><tr>
						<th width="150">Client Name</th>
						<td class="name"></td>
					</tr>
					<tr>
						<th>Appointment Date</th>
						<td class="apdate"></td>
					</tr>
					<tr>
						<th>Appointment Time</th>
						<td class="aptime"></td>
					</tr>
					<tr>
						<th>Service</th>
						<td class="service"></td>
					</tr>
					<tr>
						<th>Beautician Name</th>
						<td class="staff"></td>
					</tr>
					<tr>
						<th>Notes</th>
						<td class="spnotes"></td>
					</tr>
				</tbody></table>
				<input type="hidden" id="checkin_app_id">
			</div>
			<br>
			<div class="modal-footer">
			    <div id="checkin">
			        <button type="button" onclick="markCheckIn()" class="btn btn-filter pull-left"><i class="fa fa-check" aria-hidden="true"></i>Check In</button>
			    </div>
				<div id="but">
				    			            <a href="https://easysalon.in/demo/dashboard.php#" id="edit_md_btn"><button class="btn btn-warning" type="button"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a> 
			            <a href="https://easysalon.in/demo/dashboard.php#" id="conv_md_btn"><button class="btn btn-success" type="button"><i class="fa fa-money" aria-hidden="true"></i>Generate bill</button></a>
				</div>
				<div id="bill">
				    <!--<a href="#" id="app_billed"><button class="btn btn-success"  type="button"><i class="fa fa-money" aria-hidden="true"></i>Bill paid</button></a>-->
				</div>
				<div id="bill_cancel" style="display:none;">
				    <button class="btn btn-danger" type="button">Cancelled</button>
				</div>
				
			</div>
		</div>
		
	</div>
</div>
<!-- Modal End -->


<!-- Book appointment modal start -->
<div class="modal disableOutsideClick fade" id="book_appointment_modal" role="dialog">
	<div class="modal-dialog modal-lg" style="width:80%;">
		<!-- Modal content-->
		<div class="modal-content">
		    <form action="https://easysalon.in/demo/dashboard.php" id="dash_app" method="post">
    			<div class="modal-header">
    				<h4 class="modal-title">Book appointment</h4>
    			</div>
    			<div class="table-responsive" id="book-app-modal-body">
    			    <div class="container-fluid">
			            <div class="col-md-3">
			                <label>Client name <span class="text-danger">*</span></label>
			                <input type="text" class="client form-control client_name ui-autocomplete-input" id="client" name="client" placeholder="Autocomplete (Phone)" value="" required="" autocomplete="off">
						    <input type="hidden" name="clientid" id="clientid" value="" class="clt"> 
						    <input type="hidden" name="client_branch_id" id="client_branch_id" value="" class="clt"> 
			            </div>
			            <div class="col-md-3">
			                <label>Contact number <span class="text-danger">*</span></label>
			                <input type="text" class="form-control client ui-autocomplete-input" value="" onblur="check();contact_no_length($(this), this.value);" id="cont" name="cont" placeholder="Client contact" onkeyup="this.value = this.value.replace(/[^0-9\.]/g,&#39;&#39;);" maxlength="10" required="" autocomplete="off">
							<span style="color:red" id="client-status"></span>
							<span style="color:red" id="digit_error"></span>
			            </div>
			            <div class="col-md-3">
			                <label>Appointment date <span class="text-danger">*</span></label>
			                <input type="text" class="form-control" id="date" name="doa" required="" readonly="">
						    <span class="text-danger" id="dateerror"></span>
			            </div>
			            <div class="col-md-3">
			                <label>Gender <span class="text-danger">*</span></label>
			                <select class="form-control" name="gender" required="" id="gender">
								<option value="">--Select--</option>
								<option id="gn-1" value="1">Male</option>
								<option id="gn-2" value="2">Female</option>
							</select>
			            </div>
			            <div class="clearfix"></div><br>
			            <div class="col-md-12">
			                <table class="table table-bordered" style="margin-bottom:10px;">
            			        <thead>
            			            <tr>
            							<th colspan="2">Select service</th>
            							<!--<th>Discount</th>-->
            							<th>Artisan</th>
            							<th>Start &amp; end time</th>
            							<th>Price</th>
            						</tr>
            			        </thead>
            			        <tbody>
            			            <tr id="TextBoxContainer" class="TextBoxContainer">
            							<td style="vertical-align: middle"><span class="sno"><span class="icon-dots-three-vertical"></span></span></td>
            							<td width="450"><input type="text" class="ser form-control slot ui-autocomplete-input" name="services[]" value="" placeholder="Service (Autocomplete)" required="" autocomplete="off">
            								<input type="hidden" name="service[]" value="" class="serr">
            								<input type="hidden" name="durr[]" value="" class="durr">
            								<input type="hidden" name="pa_ser[]" value="" class="pa_ser">
            							</td>
            							<td class="spr_row" width="250"> 
            								<table id="add_row" style="width:100%" class="inner-table-space">
            								    <tbody>
            								        <tr>
                    									<td width="100%" id="select_row">
                    										<select name="staffid0[]" data-validation="required" class="form-control staff" required="">
                    											<option value="">Artisan</option>
                    										</select>
                    									</td>		
            								        </tr>
            								    </tbody>
            								</table>
            							</td>
            							<input type="hidden" name="duration[]" value="" class="duration">
            							<input type="hidden" name="ser_stime[]" value="" class="ser_stime">
            							<input type="hidden" name="ser_etime[]" value="" class="ser_etime">
            							<td>
            								<table class="inner-table-space">
            									<tbody><tr>
            										<td width="50%">
            											<input type="text" class="form-control start_time time" value="" placeholder="Start time" name="start_time[]" onchange="servicestarttime(this.value, $(this))" readonly="">
            										</td>
            										<td width="50%">
            											<input type="text" class="form-control end_time" name="end_time[]" value="" placeholder="End time" readonly="">
            										</td>
            									</tr>
            								</tbody></table>
            							</td> 
            							<td>
            								<input type="number" readonly="" class="pr form-control price positivenumber decimalnumber" step="0.01" name="price[]" id="userName" placeholder="9800.00" min="0"> 
            								<input type="hidden" class="prr">
            							</td>
            						</tr>
            						<tr id="addBefore"></tr>
            			        </tbody>
            			    </table>
            			    <div class="total-amount" style="text-align:right; font-weight: 600; margin-bottom: 10px;">
            			        <p>Total amount : <span>0.00</span></p>
            			    </div>
            			    <button type="button" id="btnAdd" class="btn btn-info pull-right"><i class="fa fa-plus" aria-hidden="true"></i>Add service</button>
			            </div>
    			    </div>
    			</div>
    			<br>
    			<div class="modal-footer">
    				<div>
    				    <input type="hidden" id="date">
    				    <input type="hidden" id="time" name="time">
    				    <input type="hidden" id="total" name="total_amount">
    				    <input type="text" class="hidden" id="close_time" value="20:00:00">
    			        <button class="btn btn-success" name="submit" type="submit"><i class="fa fa-calendar-check-o" aria-hidden="true"></i>Book appointment</button>
    	                <button class="btn btn-danger" data-dismiss="modal" type="button" onclick="$(&#39;#dash_app&#39;)[0].reset();"><i class="fa fa-times" aria-hidden="true"></i>Cancel</button>
    				</div>
    			</div>
			</form>
    	</div>
    </div>
</div>
<!-- Book appointment modal end -->
<div id="lightboxOverlay" tabindex="-1" class="lightboxOverlay" style="display: none;"></div><div id="lightbox" tabindex="-1" class="lightbox" style="display: none;"><div class="lb-outerContainer"><div class="lb-container"><img class="lb-image" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" alt=""><div class="lb-nav"><a class="lb-prev" aria-label="Previous image" href="https://easysalon.in/demo/dashboard.php"></a><a class="lb-next" aria-label="Next image" href="https://easysalon.in/demo/dashboard.php"></a></div><div class="lb-loader"><a class="lb-cancel"></a></div></div></div><div class="lb-dataContainer"><div class="lb-data"><div class="lb-details"><span class="lb-caption"></span><span class="lb-number"></span></div><div class="lb-closeContainer"><a class="lb-close"></a></div></div></div></div><div class="datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu" style="left: 0px; z-index: 10040;"><div class="datetimepicker-minutes" style="display: none;"><table class=" table-condensed"><thead><tr></tr><th class="switch text-warning" style="width: 190px;">Pick Time</th></thead><tbody class="alltimes maintime"><tr><td colspan="7"><fieldset class="minute"><legend>AM</legend><span class="minute">11:00</span><span class="minute">11:05</span><span class="minute">11:10</span><span class="minute">11:15</span><span class="minute">11:20</span><span class="minute">11:25</span><span class="minute">11:30</span><span class="minute">11:35</span><span class="minute">11:40</span><span class="minute active">11:45</span><span class="minute">11:50</span><span class="minute">11:55</span></fieldset></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr></tfoot></table></div><div class="datetimepicker-hours" style="display: block;"><table class=" table-condensed"><thead><tr></tr><th class="switch text-warning" style="width: 190px;">Pick Time</th></thead><tbody class="alltimes maintime"><tr><td colspan="7"><fieldset class="hour"><legend>AM</legend><span class="hour  hour_0 hour_am">12</span><span class="hour  hour_1 hour_am">1</span><span class="hour  hour_2 hour_am">2</span><span class="hour  hour_3 hour_am">3</span><span class="hour  hour_4 hour_am">4</span><span class="hour  hour_5 hour_am">5</span><span class="hour  hour_6 hour_am">6</span><span class="hour  hour_7 hour_am">7</span><span class="hour  hour_8 hour_am">8</span><span class="hour  hour_9 hour_am">9</span><span class="hour  hour_10 hour_am">10</span><span class="hour  active hour_11 active hour_am">11</span></fieldset><fieldset class="hour"><legend>PM</legend><span class="hour  hour_12 hour_pm">12</span><span class="hour  hour_13 hour_pm">1</span><span class="hour  hour_14 hour_pm">2</span><span class="hour  hour_15 hour_pm">3</span><span class="hour  hour_16 hour_pm">4</span><span class="hour  hour_17 hour_pm">5</span><span class="hour  hour_18 hour_pm">6</span><span class="hour  hour_19 hour_pm">7</span><span class="hour  hour_20 hour_pm">8</span><span class="hour  hour_21 hour_pm">9</span><span class="hour  hour_22 hour_pm">10</span><span class="hour  hour_23 hour_pm">11</span></fieldset></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr></tfoot></table></div><div class="datetimepicker-days" style="display: none;"><table class=" table-condensed"><thead><tr></tr><tr></tr><th class="switch text-warning" style="width: 190px;">Pick Time</th></thead><tbody class="alltimes maintime"><tr><td class="day old">30</td><td class="day old">31</td><td class="day">1</td><td class="day">2</td><td class="day active">3</td><td class="day">4</td><td class="day">5</td></tr><tr><td class="day">6</td><td class="day">7</td><td class="day">8</td><td class="day">9</td><td class="day">10</td><td class="day">11</td><td class="day">12</td></tr><tr><td class="day">13</td><td class="day">14</td><td class="day">15</td><td class="day">16</td><td class="day">17</td><td class="day">18</td><td class="day">19</td></tr><tr><td class="day">20</td><td class="day">21</td><td class="day">22</td><td class="day">23</td><td class="day">24</td><td class="day">25</td><td class="day">26</td></tr><tr><td class="day">27</td><td class="day">28</td><td class="day new">1</td><td class="day new">2</td><td class="day new">3</td><td class="day new">4</td><td class="day new">5</td></tr><tr><td class="day new">6</td><td class="day new">7</td><td class="day new">8</td><td class="day new">9</td><td class="day new">10</td><td class="day new">11</td><td class="day new">12</td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr></tfoot></table></div><div class="datetimepicker-months" style="display: none;"><table class="table-condensed"><thead><tr></tr><th class="switch text-warning" style="width: 190px;">Pick Time</th></thead><tbody class="alltimes maintime"><tr><td colspan="7"><span class="month">Jan</span><span class="month active">Feb</span><span class="month">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month">Nov</span><span class="month">Dec</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr></tfoot></table></div><div class="datetimepicker-years" style="display: none;"><table class="table-condensed"><thead><tr></tr><th class="switch text-warning" style="width: 190px;">Pick Time</th></thead><tbody class="alltimes maintime"><tr><td colspan="7"><span class="year old">2019</span><span class="year">2020</span><span class="year">2021</span><span class="year active">2022</span><span class="year">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year old">2030</span></td></tr></tbody><tfoot><tr><th colspan="7" class="today" style="display: none;">Today</th></tr></tfoot></table></div></div><ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><ul id="ui-id-2" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><ul id="ui-id-3" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="display: none;"></ul><div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div><script async="" charset="UTF-8" src="en.js"></script><div id="jofdphofooig1643868972220" style="display: block !important;"><iframe src="saved_resource.html" frameborder="0" scrolling="no" width="130px" height="64px" style="outline:none !important; visibility:visible !important; resize:none !important; box-shadow:none !important; overflow:visible !important; background:none !important; opacity:1 !important; filter:alpha(opacity=100) !important; -ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important; -mz-opacity:1 !important; -khtml-opacity:1 !important; top:auto !important; right:10px !important; bottom:0px !important; left:auto !important; position:fixed !important; border:0 !important; min-height:64px !important; min-width:130px !important; max-height:64px !important; max-width:130px !important; padding:0 !important; margin:0 !important; -moz-transition-property:none !important; -webkit-transition-property:none !important; -o-transition-property:none !important; transition-property:none !important; transform:none !important; -webkit-transform:none !important; -ms-transform:none !important; width:130px !important; height:64px !important; display:block !important; z-index:1000001 !important; background-color:transparent !important; cursor:none !important; float:none !important; border-radius:unset !important; pointer-events:auto !important; clip:auto !important;" id="f0naqju60v41643868972295" class="" title="chat widget"></iframe><iframe src="saved_resource(1).html" frameborder="0" scrolling="no" width="350px" height="520px" style="outline:none !important; visibility:visible !important; resize:none !important; box-shadow:none !important; overflow:visible !important; background:none !important; opacity:1 !important; filter:alpha(opacity=100) !important; -ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important; -mz-opacity:1 !important; -khtml-opacity:1 !important; top:auto !important; right:0px !important; bottom:0px !important; left:auto !important; position:fixed !important; border:0 !important; min-height:520px !important; min-width:350px !important; max-height:520px !important; max-width:350px !important; padding:0 !important; margin:0 !important; -moz-transition-property:none !important; -webkit-transition-property:none !important; -o-transition-property:none !important; transition-property:none !important; transform:none !important; -webkit-transform:none !important; -ms-transform:none !important; width:350px !important; height:520px !important; display:none !important; z-index:auto !important; background-color:transparent !important; cursor:none !important; float:none !important; border-radius:5px 5px  0 0 !important; pointer-events:auto !important; clip:auto !important;" id="vtslotn260981643868972383" class="" title="chat widget"></iframe><iframe src="saved_resource(2).html" frameborder="0" scrolling="no" width="360px" height="246px" style="outline:none !important; visibility:visible !important; resize:none !important; box-shadow:none !important; overflow:visible !important; background:none !important; opacity:1 !important; filter:alpha(opacity=100) !important; -ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important; -mz-opacity:1 !important; -khtml-opacity:1 !important; top:auto !important; right:10px !important; bottom:80px; left:auto !important; position:fixed !important; border:0 !important; min-height:246px !important; min-width:360px !important; max-height:246px !important; max-width:360px !important; padding:0 !important; margin:0 !important; -moz-transition-property:none !important; -webkit-transition-property:none !important; -o-transition-property:none !important; transition-property:none !important; transform:none !important; -webkit-transform:none !important; -ms-transform:none !important; width:360px !important; height:246px !important; display:block !important; z-index:auto !important; background-color:transparent !important; cursor:none !important; float:none !important; border-radius:unset !important; pointer-events:auto !important; clip:auto !important;" id="ua07j3m50n2g1643868972350" class="" title="chat widget"></iframe><iframe src="saved_resource(3).html" frameborder="0" scrolling="no" width="215px" height="119px" style="outline:none !important; visibility:visible !important; resize:none !important; box-shadow:none !important; overflow:visible !important; background:none !important; opacity:1 !important; filter:alpha(opacity=100) !important; -ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity 1}) !important; -mz-opacity:1 !important; -khtml-opacity:1 !important; top:auto !important; right:0px !important; bottom:53px !important; left:auto !important; position:fixed !important; border:0 !important; min-height:119px !important; min-width:215px !important; max-height:119px !important; max-width:215px !important; padding:0 !important; margin:0px 0 0 0 !important; -moz-transition-property:none !important; -webkit-transition-property:none !important; -o-transition-property:none !important; transition-property:none !important; transform:rotate(0deg) translateZ(0); -webkit-transform:rotate(0deg) translateZ(0); -ms-transform:rotate(0deg) translateZ(0); width:215px !important; height:119px !important; display:none !important; z-index:1000000 !important; background-color:transparent !important; cursor:none !important; float:none !important; border-radius:unset !important; pointer-events:auto !important; clip:auto !important; -moz-transform:rotate(0deg) translateZ(0); -o-transform:rotate(0deg) translateZ(0); transform-origin:0; -moz-transform-origin:0; -webkit-transform-origin:0; -o-transform-origin:0; -ms-transform-origin:0;" id="ce3aapha77ig1643868972324" class="" title="chat widget"></iframe></div></body></html>