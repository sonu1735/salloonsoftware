

<div class="dashboard-wrapper">
	<!-- Main container starts -->
	<div class="main-container">
		<!-- Row starts -->
		<div class="row gutter">
		    <div class="col-lg-4 col-md-4 col-sm-2 hidden-xs"></div>
			<div class="col-lg-4 col-md-4 col-sm-8 col-xs-12">
				 <?php if($this->session->flashdata('message')) { ?>
           
                
  <?php echo $this->session->flashdata('message')?>
  
        <?php } ?> 
				<div class="panel" style="border:1px solid #032f54;">
					<div class="panel-heading"  style="background-color: #032f54;border-radius: 0px;color: #ffffff;">
						<h4 class="text-center">Update profile / password</h4>
					</div>

					<div class="panel-body">
						<div class="row">
						 <form action="<?php echo base_url('admin/Login/password_cheak'); ?>" method="post" onkeyup="validate()">
                                                        <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="name">Enter name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" required=""  value="<?php echo $getDetails->name;?>" name="name" placeholder="Name">
                                </div>
                            </div>
                                                        <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="user">Username</label>
                                    <input type="text" class="form-control" value="<?php echo $getDetails->email;?>" name="name"  placeholder="username" readonly="">
                                    <span id="user-status"></span>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="pass1">Old Password <span class="text-danger">*</span></label>
                                    <input type="password"  class="form-control" name="oldpassword" id="pass1" autocomplete="off" placeholder="Enter Old Password">
                                    <span  class="text-danger"></span>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="pass2">New password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" name="newpassword" id="newpassword" placeholder="Enter New Password">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12">
                            	<div class="form-group">
                                    <label for="pass2">Confirm Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" name="confirmpassword" id="cpass" placeholder="Enter New Password" required="newpassword">
                                </div>
                                 <div class="col-auto my-1">
                        <button type="submit" id="sub" class="btn btn-success">Submit</button>
                        <button type="submit" class="btn btn-danger">Cancel</button>
                        </div>
                            </div>
                            </form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Row ends -->
	</div>
	<!-- Main container ends -->
</div>
<!-- Dashboard Wrapper End -->
</div>
<!-- Container fluid ends -->
<script>
    function validate() {
    
    var newpassword=$('#newpassword').val();
     var cpass=$('#cpass').val();
     if(newpassword==cpass)
     {
      
      var err=$('#message').html('');
       $('#sub').removeAttr('disabled');
        
     }
     else{
           var rr="Error Pass";
      var err=$('#message').html(rr);
      $('#sub').attr('disabled','disabled');
     }

  }
    $('#hh').delay(3000).slideUp();
    </script>