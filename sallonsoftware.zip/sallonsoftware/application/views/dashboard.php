 
<style type="text/css">
	.fc-time-grid-container{
		height: auto!important;
	}
	.fc-content{
	    cursor: pointer;
	}
	.fc-today-button, .fc-axis, .fc-resourceTimeGridDay-button, .fc-resourceTimeGridWeek-button, .fc-resourceDayGridMonth-button{
	   text-transform: capitalize;
	}
	.ui-autocomplete{
	    z-index: 9999;
	}
	.pending-appointment{
	    background-color: #f1c40f;
	    border-color: #f1c40f;
	}
	.cancelled-appointment{
	    background-color: #ff0000;
	    border-color: #ff0000;
	}
	.billed-appointment{
	    background-color: #048a04;
	    border-color: #048a04;
	}
	.checkedin-appointment{
	    background-color: #2d00a7;
	    border-color: #2d00a7;
	}
	
	.fc-time-grid .fc-slats {
	    /*z-index: 4;*/
	    /*pointer-events: none;*/
	 }

	.fc-resourceDayGridMonth-view .fc-widget-content, .fc-resourceDayGridMonth-view .fc-day-grid-container{
	    height: auto!important;
	    min-height: 8em!important;
	}

	.fc-time-grid .fc-event, .fc-time-grid .fc-bgevent{
	    min-height : 15px;
	}
	
	.fc-resourceDayGridMonth-view .fc-day-grid-container{
	    min-height:600px!important;
	}
	
	.fc-view {
        overflow-x: auto;
	 }
	
	
	.fc-scroller.fc-time-grid-container {
	    overflow: initial !important;
	 }
	
	.fc-axis {
        position: sticky;
        left: 0;
        background: white;
    }
    
    .popover {
        background: #fff;
        border-radius: 8px;
        border:1px solid #ccc;
	}
	.popover.top > .arrow:after { border-top-color: #ccc; }

</style>
<!-- Navbar ends -->
<!-- Dashboard wrapper starts -->
<div class="dashboard-wrapper">
	
	<!-- Main container starts -->
	<div class="main-container">
		
		<!-- Row starts -->
		<div class="row gutter">
							<div class="col-lg-3 col-md-6 col-sm-6" >
					<a href="javascript:void(0)" id="sales"><div class="mini-widget">
						<div class="mini-widget-heading clearfix" >
							<div class="pull-left">Today Sales</div>
							<!-- <div class="pull-right"><i class="icon-arrow--right2"></i> 0%</div> -->
						</div>
						<div class="mini-widget-body clearfix" id="salesDashboardLoader">
							<div class="pull-left">
								<i class="icon-credit-card"></i>
							</div>
							<div class="pull-right number">INR <span id='todaysalesValue'></span></div>
						</div>
					</div></a>
				</div>				<input type="hidden" value="2022-02-03" id="fromDate"/>
				<input type="hidden" value="2022-02-03" id="toDate"/>
				<div class="col-lg-3 col-md-6 col-sm-6">
					<a id="appointment"><div class="mini-widget red">
						<div class="mini-widget-heading clearfix">
							<div class="pull-left">Today Appointments</div>
							<!-- <div class="pull-right"><i class="icon-arrow--right2"></i>0%</div> -->
						</div>
						
						<div class="mini-widget-body clearfix" id="appointmentDashboardLoader">
							<div class="pull-left">
								<i class="icon-perm_phone_msg"></i>
							</div>
							<div class="pull-right number"><span id='todayappointmentValue'></span></div>
						</div>
					</div></a>
				</div>
									<div class="col-lg-3 col-md-6 col-sm-6">
						<a href="javascript:void(0)" id="enquiry"><div class="mini-widget grey">
							<div class="mini-widget-heading clearfix">
								<div class="pull-left">Today Enquiry</div>
								<!-- <div class="pull-right"><i class="icon-arrow--right2"></i>0%</div> -->
							</div>
							<div class="mini-widget-body clearfix" id="enquiryDashboardLoader">
								<div class="pull-left">
									<i class="icon-add-user"></i>
								</div>
								<div class="pull-right number"><span id='enquiryValue'></span></div>
							</div>
						</div></a>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6">
						<a id="clients"><div class="mini-widget green">
							<div class="mini-widget-heading clearfix">
								<div class="pull-left">Clients Visit</div>
								<!-- <div class="pull-right"><i class="icon-arrow--right2"></i> 0%</div> -->
							</div>
							<div class="mini-widget-body clearfix" id="clientsDashboardLoader">
								<div class="pull-left">
									<i class="icon-emoji-happy"></i>
								</div>
								<div class="pull-right number"><span id='clientsValue'></span></div>
							</div>
						</div></a>
					</div>				</div>
				<div class="color-code-indecation">
				    <ul class="pull-right">
				        <li style="display:inline-block;margin-right:10px;"><span class="pending-appointment" style="height:11px;width:11px;display:inline-block;"></span> Pending</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="checkedin-appointment" style="height:11px;width:11px;display:inline-block;"></span> Checked In</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="billed-appointment" style="height:11px;width:11px;display:inline-block;"></span> Billed</li>
				        <li style="display:inline-block;margin-right:10px;"><span class="cancelled-appointment" style="height:11px;width:11px;display:inline-block;"></span> Cancelled</li>
				    </ul>
				</div>
				<div class="clearfix"></div><br />
        		<div id="todaysalesDashboard"> 
        		</div> 
		
		
		<!-- Row ends -->
		
		
		
		<div id="calendar" class="fc-calendar"></div> 
		<!-- Row starts -->
	</div>
	<!-- Main container ends -->
	
</div>
<!-- Dashboard Wrapper End -->

</div>
<!-- Container fluid ends -->

