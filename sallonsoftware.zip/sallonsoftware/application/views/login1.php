
<!DOCTYPE html>
<html lang="en" class="html">

<!-- Mirrored from online.daysmartsalon.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Feb 2022 05:28:48 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <title>DaySmart Salon Login: Online Scheduling Software for Salon &amp; Spas</title>
    <meta name="description" content="Login &amp; start growing your business now. Have a question or first time setup? Give us a call at (800) 604-2040 if you need support. We&#39;re here to help!" />
    <meta name="keywords" content="" />
    <meta charset="UTF-8"><script type="text/javascript">window.NREUM||(NREUM={});NREUM.info = {"beacon":"bam-cell.nr-data.net","errorBeacon":"bam-cell.nr-data.net","licenseKey":"01a7c848cf","applicationID":"566819260,48996515,565985570","transactionName":"YwdTMhAHXEQDAUEKDVpNfDAhSXpYDwd2DAxAEF4KDgNAGCsMUQYa","queueTime":0,"applicationTime":261,"agent":"","atts":""}</script><script type="text/javascript">(window.NREUM||(NREUM={})).init={ajax:{deny_list:["bam-cell.nr-data.net"]}};(window.NREUM||(NREUM={})).loader_config={licenseKey:"01a7c848cf",applicationID:"566819260"};window.NREUM||(NREUM={}),__nr_require=function(t,e,n){function r(n){if(!e[n]){var i=e[n]={exports:{}};t[n][0].call(i.exports,function(e){var i=t[n][1][e];return r(i||e)},i,i.exports)}return e[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var i=0;i<n.length;i++)r(n[i]);return r}({1:[function(t,e,n){function r(){}function i(t,e,n,r){return function(){return s.recordSupportability("API/"+e+"/called"),o(t+e,[u.now()].concat(c(arguments)),n?null:this,r),n?void 0:this}}var o=t("handle"),a=t(10),c=t(11),f=t("ee").get("tracer"),u=t("loader"),s=t(4),d=NREUM;"undefined"==typeof window.newrelic&&(newrelic=d);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",v=l+"ixn-";a(p,function(t,e){d[e]=i(l,e,!0,"api")}),d.addPageAction=i(l,"addPageAction",!0),d.setCurrentRouteName=i(l,"routeName",!0),e.exports=newrelic,d.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(t,e){var n={},r=this,i="function"==typeof e;return o(v+"tracer",[u.now(),t,n],r),function(){if(f.emit((i?"":"no-")+"fn-start",[u.now(),r,i],n),i)try{return e.apply(this,arguments)}catch(t){throw f.emit("fn-err",[arguments,this,t],n),t}finally{f.emit("fn-end",[u.now()],n)}}}};a("actionText,setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(t,e){m[e]=i(v,e)}),newrelic.noticeError=function(t,e){"string"==typeof t&&(t=new Error(t)),s.recordSupportability("API/noticeError/called"),o("err",[t,u.now(),!1,e])}},{}],2:[function(t,e,n){function r(t){if(NREUM.init){for(var e=NREUM.init,n=t.split("."),r=0;r<n.length-1;r++)if(e=e[n[r]],"object"!=typeof e)return;return e=e[n[n.length-1]]}}e.exports={getConfiguration:r}},{}],3:[function(t,e,n){var r=!1;try{var i=Object.defineProperty({},"passive",{get:function(){r=!0}});window.addEventListener("testPassive",null,i),window.removeEventListener("testPassive",null,i)}catch(o){}e.exports=function(t){return r?{passive:!0,capture:!!t}:!!t}},{}],4:[function(t,e,n){function r(t,e){var n=[a,t,{name:t},e];return o("storeMetric",n,null,"api"),n}function i(t,e){var n=[c,t,{name:t},e];return o("storeEventMetrics",n,null,"api"),n}var o=t("handle"),a="sm",c="cm";e.exports={constants:{SUPPORTABILITY_METRIC:a,CUSTOM_METRIC:c},recordSupportability:r,recordCustom:i}},{}],5:[function(t,e,n){function r(){return c.exists&&performance.now?Math.round(performance.now()):(o=Math.max((new Date).getTime(),o))-a}function i(){return o}var o=(new Date).getTime(),a=o,c=t(12);e.exports=r,e.exports.offset=a,e.exports.getLastTimestamp=i},{}],6:[function(t,e,n){function r(t){return!(!t||!t.protocol||"file:"===t.protocol)}e.exports=r},{}],7:[function(t,e,n){function r(t,e){var n=t.getEntries();n.forEach(function(t){"first-paint"===t.name?l("timing",["fp",Math.floor(t.startTime)]):"first-contentful-paint"===t.name&&l("timing",["fcp",Math.floor(t.startTime)])})}function i(t,e){var n=t.getEntries();if(n.length>0){var r=n[n.length-1];if(u&&u<r.startTime)return;var i=[r],o=a({});o&&i.push(o),l("lcp",i)}}function o(t){t.getEntries().forEach(function(t){t.hadRecentInput||l("cls",[t])})}function a(t){var e=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(e)return e.type&&(t["net-type"]=e.type),e.effectiveType&&(t["net-etype"]=e.effectiveType),e.rtt&&(t["net-rtt"]=e.rtt),e.downlink&&(t["net-dlink"]=e.downlink),t}function c(t){if(t instanceof y&&!w){var e=Math.round(t.timeStamp),n={type:t.type};a(n),e<=v.now()?n.fid=v.now()-e:e>v.offset&&e<=Date.now()?(e-=v.offset,n.fid=v.now()-e):e=v.now(),w=!0,l("timing",["fi",e,n])}}function f(t){"hidden"===t&&(u=v.now(),l("pageHide",[u]))}if(!("init"in NREUM&&"page_view_timing"in NREUM.init&&"enabled"in NREUM.init.page_view_timing&&NREUM.init.page_view_timing.enabled===!1)){var u,s,d,p,l=t("handle"),v=t("loader"),m=t(9),g=t(3),y=NREUM.o.EV;if("PerformanceObserver"in window&&"function"==typeof window.PerformanceObserver){s=new PerformanceObserver(r);try{s.observe({entryTypes:["paint"]})}catch(h){}d=new PerformanceObserver(i);try{d.observe({entryTypes:["largest-contentful-paint"]})}catch(h){}p=new PerformanceObserver(o);try{p.observe({type:"layout-shift",buffered:!0})}catch(h){}}if("addEventListener"in document){var w=!1,b=["click","keydown","mousedown","pointerdown","touchstart"];b.forEach(function(t){document.addEventListener(t,c,g(!1))})}m(f)}},{}],8:[function(t,e,n){function r(t,e){if(!i)return!1;if(t!==i)return!1;if(!e)return!0;if(!o)return!1;for(var n=o.split("."),r=e.split("."),a=0;a<r.length;a++)if(r[a]!==n[a])return!1;return!0}var i=null,o=null,a=/Version\/(\S+)\s+Safari/;if(navigator.userAgent){var c=navigator.userAgent,f=c.match(a);f&&c.indexOf("Chrome")===-1&&c.indexOf("Chromium")===-1&&(i="Safari",o=f[1])}e.exports={agent:i,version:o,match:r}},{}],9:[function(t,e,n){function r(t){function e(){t(c&&document[c]?document[c]:document[o]?"hidden":"visible")}"addEventListener"in document&&a&&document.addEventListener(a,e,i(!1))}var i=t(3);e.exports=r;var o,a,c;"undefined"!=typeof document.hidden?(o="hidden",a="visibilitychange",c="visibilityState"):"undefined"!=typeof document.msHidden?(o="msHidden",a="msvisibilitychange"):"undefined"!=typeof document.webkitHidden&&(o="webkitHidden",a="webkitvisibilitychange",c="webkitVisibilityState")},{}],10:[function(t,e,n){function r(t,e){var n=[],r="",o=0;for(r in t)i.call(t,r)&&(n[o]=e(r,t[r]),o+=1);return n}var i=Object.prototype.hasOwnProperty;e.exports=r},{}],11:[function(t,e,n){function r(t,e,n){e||(e=0),"undefined"==typeof n&&(n=t?t.length:0);for(var r=-1,i=n-e||0,o=Array(i<0?0:i);++r<i;)o[r]=t[e+r];return o}e.exports=r},{}],12:[function(t,e,n){e.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(t,e,n){function r(){}function i(t){function e(t){return t&&t instanceof r?t:t?u(t,f,a):a()}function n(n,r,i,o,a){if(a!==!1&&(a=!0),!l.aborted||o){t&&a&&t(n,r,i);for(var c=e(i),f=m(n),u=f.length,s=0;s<u;s++)f[s].apply(c,r);var p=d[w[n]];return p&&p.push([b,n,r,c]),c}}function o(t,e){h[t]=m(t).concat(e)}function v(t,e){var n=h[t];if(n)for(var r=0;r<n.length;r++)n[r]===e&&n.splice(r,1)}function m(t){return h[t]||[]}function g(t){return p[t]=p[t]||i(n)}function y(t,e){l.aborted||s(t,function(t,n){e=e||"feature",w[n]=e,e in d||(d[e]=[])})}var h={},w={},b={on:o,addEventListener:o,removeEventListener:v,emit:n,get:g,listeners:m,context:e,buffer:y,abort:c,aborted:!1};return b}function o(t){return u(t,f,a)}function a(){return new r}function c(){(d.api||d.feature)&&(l.aborted=!0,d=l.backlog={})}var f="nr@context",u=t("gos"),s=t(10),d={},p={},l=e.exports=i();e.exports.getOrSetContext=o,l.backlog=d},{}],gos:[function(t,e,n){function r(t,e,n){if(i.call(t,e))return t[e];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,e,{value:r,writable:!0,enumerable:!1}),r}catch(o){}return t[e]=r,r}var i=Object.prototype.hasOwnProperty;e.exports=r},{}],handle:[function(t,e,n){function r(t,e,n,r){i.buffer([t],r),i.emit(t,e,n)}var i=t("ee").get("handle");e.exports=r,r.ee=i},{}],id:[function(t,e,n){function r(t){var e=typeof t;return!t||"object"!==e&&"function"!==e?-1:t===window?0:a(t,o,function(){return i++})}var i=1,o="nr@id",a=t("gos");e.exports=r},{}],loader:[function(t,e,n){function r(){if(!P++){var t=M.info=NREUM.info,e=g.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(t&&t.licenseKey&&t.applicationID&&e))return u.abort();f(O,function(e,n){t[e]||(t[e]=n)});var n=a();c("mark",["onload",n+M.offset],null,"api"),c("timing",["load",n]);var r=g.createElement("script");0===t.agent.indexOf("http://")||0===t.agent.indexOf("https:///")?r.src=t.agent:r.src=v+"://"+t.agent,e.parentNode.insertBefore(r,e)}}function i(){"complete"===g.readyState&&o()}function o(){c("mark",["domContent",a()+M.offset],null,"api")}var a=t(5),c=t("handle"),f=t(10),u=t("ee"),s=t(8),d=t(6),p=t(2),l=t(3),v=p.getConfiguration("ssl")===!1?"http":"https",m=window,g=m.document,y="addEventListener",h="attachEvent",w=m.XMLHttpRequest,b=w&&w.prototype,E=!d(m.location);NREUM.o={ST:setTimeout,SI:m.setImmediate,CT:clearTimeout,XHR:w,REQ:m.Request,EV:m.Event,PR:m.Promise,MO:m.MutationObserver};var x=""+location,O={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1215.min.js"},T=w&&b&&b[y]&&!/CriOS/.test(navigator.userAgent),M=e.exports={offset:a.getLastTimestamp(),now:a,origin:x,features:{},xhrWrappable:T,userAgent:s,disabled:E};if(!E){t(1),t(7),g[y]?(g[y]("DOMContentLoaded",o,l(!1)),m[y]("load",r,l(!1))):(g[h]("onreadystatechange",i),m[h]("onload",r)),c("mark",["firstbyte",a.getLastTimestamp()],null,"api");var P=0}},{}],"wrap-function":[function(t,e,n){function r(t,e){function n(e,n,r,f,u){function nrWrapper(){var o,a,s,p;try{a=this,o=d(arguments),s="function"==typeof r?r(o,a):r||{}}catch(l){i([l,"",[o,a,f],s],t)}c(n+"start",[o,a,f],s,u);try{return p=e.apply(a,o)}catch(v){throw c(n+"err",[o,a,v],s,u),v}finally{c(n+"end",[o,a,p],s,u)}}return a(e)?e:(n||(n=""),nrWrapper[p]=e,o(e,nrWrapper,t),nrWrapper)}function r(t,e,r,i,o){r||(r="");var c,f,u,s="-"===r.charAt(0);for(u=0;u<e.length;u++)f=e[u],c=t[f],a(c)||(t[f]=n(c,s?f+r:r,i,f,o))}function c(n,r,o,a){if(!v||e){var c=v;v=!0;try{t.emit(n,r,o,e,a)}catch(f){i([f,n,r,o],t)}v=c}}return t||(t=s),n.inPlace=r,n.flag=p,n}function i(t,e){e||(e=s);try{e.emit("internal-error",t)}catch(n){}}function o(t,e,n){if(Object.defineProperty&&Object.keys)try{var r=Object.keys(t);return r.forEach(function(n){Object.defineProperty(e,n,{get:function(){return t[n]},set:function(e){return t[n]=e,e}})}),e}catch(o){i([o],n)}for(var a in t)l.call(t,a)&&(e[a]=t[a]);return e}function a(t){return!(t&&t instanceof Function&&t.apply&&!t[p])}function c(t,e){var n=e(t);return n[p]=t,o(t,n,s),n}function f(t,e,n){var r=t[e];t[e]=c(r,n)}function u(){for(var t=arguments.length,e=new Array(t),n=0;n<t;++n)e[n]=arguments[n];return e}var s=t("ee"),d=t(11),p="nr@original",l=Object.prototype.hasOwnProperty,v=!1;e.exports=r,e.exports.wrapFunction=c,e.exports.wrapInPlace=f,e.exports.argsToArray=u},{}]},{},["loader"]);</script>
    <meta name="viewport" content="width=device-width" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.0/font/bootstrap-icons.css">

    <link rel="shortcut icon" href="<?php echo base_url('assets/adminlink')?>Content/images_shared/logos/saloniris.ico" />
    <link href="<?php echo base_url('assets/adminlink/')?>Content/v3/thirdparty/jqueryui/ThirdpartyPlugins980a.css?v=CqWPSZuND-amTiCdxrM-bX3WbiXwC2V-NyEvvtZBsSY1" rel="stylesheet"/>

    <link href="<?php echo base_url('assets/adminlink/')?>Bundle/Style/Core1006.css?v=dhKmXBkBbGKeSWccXFH-ymEf0zys1OsMPGtV7tk-s9A1" rel="stylesheet"/>
<link href="<?php echo base_url('assets/adminlink/')?>Content/v3/thirdparty/jqueryui/jQueryUidf8f.css?v=vRnAthpNFLe7i6TjfpRcR2f7ssg85NRMXZ5ViqsfwHQ1" rel="stylesheet"/>
<link href="<?php echo base_url('assets/adminlink/')?>Content/v3/thirdparty/kendoui/KendoUi124d.css?v=C6riA2orKzk7xH51yPytPm9o8FhfQ7EvZY32jMnbHYU1" rel="stylesheet"/>
<link href="<?php echo base_url('assets/adminlink/')?>Bundle/Style/Fonts0dcc.css?v=g-pjHCx0iF6uahe72wwsqBXE7_2RR0anC7I7-PUIAx41" rel="stylesheet"/>
<link href="<?php echo base_url('assets/adminlink/')?>Bundle/Style/theme/salmon3af7.css?v=F01-7n4RyMTaT-m22EAX2PXf1q7uNBEFKQ_hOs8hUHA1" rel="stylesheet"/>
<link href="<?php echo base_url('assets/adminlink/')?>Bundle/Style/libraries/homeec92.css?v=" rel="stylesheet"/>




    
    

</head>

<body class="body  _saloniris full-height">
    <script>
    localStorage.removeItem('FullSession');
    localStorage.removeItem('FullSessionTimeStamp');
    var currentSavedUi = window.sessionStorage.getItem("dsi.uielements");
    var newSavedUi = {};
    if (currentSavedUi) {
        newSavedUi = JSON.parse(currentSavedUi);

        delete newSavedUi["appointment-book-banner"];
        let newSavedUiString = JSON.stringify(newSavedUi);
        if (!newSavedUiString === "{}")
            window.sessionStorage.setItem("dsi.uielements", newSavedUiString);
        else
            window.sessionStorage.clear();
    }
</script>
 

<link rel="preconnect" href="https://fonts.googleapis.com/">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans&amp;display=swap" rel="stylesheet">

<div id="content-background full-height">
    <div id="login-page-center">
        <div class="left login-page-box login-page-box-wide">
            <img class="login-page-logo _saloniris" src="<?php echo base_url('assets/adminlink/')?>Content/images_shared/logos/login_saloniris.svg" alt="logo" />
            <div class="clear"></div>
            
            <form class="pt-3" action="<?php echo base_url('admin/Login/login_process');?>" id="login" method="post">
                <div class="login-page-box-wide-content">




                    <?php if($this->session->flashdata('message')): ?>
  <div class="alert alert-danger">
  <strong><?php echo $this->session->flashdata('message'); ?></strong>
</div>
  
<?php endif; ?>     
                            <div>
                                <p class="field-label">Email Address:</p>
                                 <input type="email" class="form-control form-control-lg"  name="email" placeholder="Username" required="">
                                <p class="field-label">Password:</p>
                                 <input type="password" name="password" class="form-control form-control-lg" id="password" placeholder="Password" required="">
                             </div>
                              <span id="message" style="color:red;"></span>
                                <!-- <a id="ForgotPassword" data-event="View.Home.ShowForgotPassword" class="colorLink small-font">forgot your password?</a>
 -->
                                <br />
                                <label>
                                    <span class="custom-checkbox login-remember-user left">
                                        <input type="checkbox" id="remember-user" />
                                        <span class="box"><span class="tick"></span></span>
                                    </span>
                                    <span class="login-remember-user left">
                                        Keep me logged in
                                    </span>
                                </label>
                                <button class="smallButtonColor login-button" name="login" type="submit">Log In</button>
                                <!-- <a class="smallButtonColor login-button" type="submit" >Log In</a> -->
                                <div class="account-button-section">
                                    <div>
                                        New to DaySmart Salon?<br />
                                    </div>
                                    <div>
                                        <a id="signup-button" class="colorLink" href="Account/NewAccount.html">Create an account</a> for your business.
                                    </div>
                                </div>
                            </div>


                </div>
            </form>
        </div>
    </div>
</div>
<div id="footer-outline">
    <div id="footer-main">
                <span id="salonFooter">
                    <span>&copy;2022 DaySmart Software design by </span> <br />
                    <a class="colorLink" href="http://www.Animationmedia.org/">Animationmedia</a>
                </span>

    </div>
</div>



    <!-- BUILD NUMBER: 2022.01.25-ff32d72 -->

<script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/Analytics12eb?v=Yp4thYAozOmn2XtrpAafAZW7tFYKQy0_S7y-FwbhIBA1"></script>
    <script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/jQuery3504?v=Pe8bVgSgAGAJn56QwYkgYiZ9dUnFILh_8dsV21sSCw01"></script>
<script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/KendoUiba5f?v=gY3FOubYkifBBjNNj1aIpmBWuEpWl4fS9rZFtIocASU1"></script>

    <script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/ThirdpartyPluginsa792?v=-GmdYLyv2RQ-BmdA-M9rJwRsLoAtNC1VZiPZQLald4k1"></script>

    <script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/Coreaa9f?v=v4TbEIm5gWu6021uqw_TlQrHCUsK33qJI_aI3ol5OgM1"></script>
<script src="<?php echo base_url('assets/adminlink')?>Bundle/Script/libraries/homed7e1?v=ACA5ImVj5abchCxR7Ql_lUWBqrW8eYo9mZt5JPkuMrk1"></script>

<!-- <script type="text/javascript">
    $(document).ready(function()
    {//alert()
        $("#login").on("submit", function(e)
        {
            e.preventDefault();
            var frm=$(this);
            var url=frm.attr('action');
            checklogin('login',url);
            
         });
    });
</script> -->
<script src="jquery-3.5.1.min.js"></script>
<script>
    $('#hh').delay(3000).slideUp();
    </script>
    
    
        </body>
    
<!-- Mirrored from online.daysmartsalon.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Feb 2022 05:28:59 GMT -->
</html>