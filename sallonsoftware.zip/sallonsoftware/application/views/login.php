<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from easysalon.in/demo/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Feb 2022 12:42:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	
		<meta name="author" content="13DesignStreet" />
		<link rel="shortcut icon" href="img/favicon.html">
		<title>Easy salon & spa software</title>
		
		<!-- Bootstrap CSS -->
		<link href="<?php echo base_url('assets/')?>/css/bootstrap.min.css" rel="stylesheet" media="screen" />

		<!-- Login CSS -->
		<link href="<?php echo base_url('assets/')?>/css/main.css" rel="stylesheet" />
		<!-- Ion Icons -->
		<link href="<?php echo base_url('assets/')?>/fonts/icomoon/icomoon.css" rel="stylesheet" />
		<script src="../../code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
		<!-- Calendar CSS -->
		<script src="<?php echo base_url('assets/')?>/js/jquery.js"></script>
		<link rel="stylesheet" href="../../code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
		<script src="../../code.jquery.com/jquery-1.10.2.js"></script>
		<script src="../../code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/')?>/js/jquery-form.js"></script>
		<script type="text/javascript" src="../../cdnjs.cloudflare.com/ajax/libs/toastr.js/1.3.1/js/toastr.js"></script>
		<link rel="stylesheet" type="text/css" href="../../cdnjs.cloudflare.com/ajax/libs/toastr.js/1.3.1/css/toastr.css">
		<style>
		    html{
		        height: auto;
		    }
		    .support{
		        font-weight: 600;
		    }
		    .container-fluid{
		        margin: 30px;
		    }
		    .login{
		        padding-top: 0px;
		        padding-bottom: 0px;
		    }
		    .login-wrapper .login .login-body{
		        margin: 0px;
		    }
		</style>
	</head>
	
	
		<body  style="background-size:cover;background-position: center; background-repeat: no-repeat;background-image:url('assets/upload/login_page_bg/1627075774.jpg');">
		
			<div class="login-wrapper">
				<div class="login">
				<form action="<?php echo base_url('Welcome/dashboard')?>" method="post">
					<div class="login-header" style="margin:0px;">
						<img id="site_logo" src="<?php echo base_url('assets/')?>upload/1629668471.png" alt="AK Unisex salon" style="margin:0px auto;max-width:200px;" class="img-responsive" />
						<!--<h5>Login to access to your Shiv Admin Dashboard.</h5>-->
					</div>
					<div class="login-body">
						<div id="branch_option" style="display: none;">
							<div class="form-group">
								<label for="emailID">Select branch</label>
								<select class="form-control" id="branch">
									<option value="1" selected>--Select--</option>
									<option value="1" >Branch 1</option>								</select>
							</div>
							<button class="btn btn-danger btn-block" name="continue" id="continue" type="button">Continue</button>
						</div>
						<div id="login_form" style="display:block;">
							<div class="form-group">
								<input id="emailID" type="text" name="user" value="admin" required class="form-control" placeholder="Username">
							</div>
							<div class="form-group">
								<input id="password" type="password" required value="admin@123" name="pass" class="form-control" placeholder="Password">
							</div>
							<input type="hidden" name="branch_id" id="branch_id" value="1" />
							<button class="btn btn-danger btn-block" name="signin" type="submit">Sign in</button>
							<p style="cursor: pointer;text-align: left;display: none;" id="change_branch">Change branch</p>
						</div>
					</div>
					
                    
                   
                   </form> 
				    <div class="clearfix"></div>
                    <p class="text-left support">For support : manager@easysalon.in <br> +91-78884-91153, +91-78884-91154</p>  
				</div>
              
			</div>
	
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center" style="color:#fff;"><strong>Customer Reviews</strong></h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <iframe width="100%" height="200" src="https://www.youtube.com/embed/yO4cpszyvak" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="col-md-4">
                        <iframe width="100%" height="200" src="https://youtu.be/CrpP10F9cFA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="col-md-4">
                    	<iframe id="player" type="text/html" width="100%" height="200"
  src="http://www.youtube.com/embed/M7lc1UVf-VE?enablejsapi=1&origin=http://example.com"
  frameborder="0"></iframe>
                       
                    </div>
                </div>
            </div>
         
		
		
		
<script>

$(document).ready(function(){
// 	$('#login_form').hide();
	$('#continue').on('click',function(){
		var branch = $('#branch').val();
		if(branch == ''){
			toastr.warning('Please select branch');
		} else {
			$('#branch_id').val(branch);
			$('#branch_option').hide();
			$('#login_form').show();
		}
	});

	$('#change_branch').on('click',function(){
		$('#branch_option').show();
		$('#login_form').hide();
	});

	$('#branch').on('change', function(){
		var branch = $(this).val();
		if(branch > 0){
			$.ajax({
				url : 'ajax/system_details.php',
				type : 'post',
				data : { action : 'logo_url', branch_id : branch },
				dataType : 'json',
				success : function(response){
					if(response.status == 1){
						if(response.logo_url != ''){
							$('#site_logo').attr('src',response.logo_url);
						}
						if(response.bg_url != ''){
							$('body').attr('style','background-size: cover; background-position: center center; background-repeat: no-repeat; background-image: url("'+response.bg_url+'")');
						}
					}
				}
			});
		} else {
			$('#site_logo').attr('src','upload/1629668471.png');
			$('body').attr('style','background-size: cover; background-position: center center; background-repeat: no-repeat; background-image: url("upload/login_page_bg/1627075774.jpg")');
		}
	});

});

function myalert() {
		
	}
</script>      
	</body>

<!-- Mirrored from easysalon.in/demo/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Feb 2022 12:43:03 GMT -->
</html>