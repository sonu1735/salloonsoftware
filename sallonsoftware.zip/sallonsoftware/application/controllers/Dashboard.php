<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	 public function __construct()
	{
	  parent::__construct();
	   $this->load->library('session');
	     $this->load->model('admin/Model_login'); //Load the Model here   
	  $this->logged();
	
	}

	private function logged(){
		// die(print_r($this->session->userdata()));
		if(!$this->session->userdata('email')) {
			redirect('welcome/index');
		}
		
	}
	public function welcomedashboard()
	{
		
        $this->load->view('adminfile/includes/header');
		$this->load->view('adminfile/dashboard');
		 $this->load->view('adminfile/includes/footer');
	}
	public function changepassword()
	{

        $loginDetails          =    $this->session->userdata('email');

		$data['getDetails']    =    $this->Model_login->getLogindetails($loginDetails);

		$this->load->view('adminfile/includes/header',$data);

		$this->load->view('adminfile/changepassword',$data);
		
		$this->load->view('adminfile/includes/footer',$data);
	}
}
