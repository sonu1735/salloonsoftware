<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
function __construct(){
	parent::__construct();
	 $this->load->library('session');
	$this->load->model('admin/Model_login');
    // copy your old constructor function code here
 }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function Login()
	{
		$this->form_validation->set_rules('email', 'email', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        if ($this->form_validation->run() == TRUE) {
        	$username=$this->input->post('email');
        	$password=$this->input->post('password');

       		    $login = $this->Model_login->login($username,$password);

                if($login!=false){
                	$logged_in_sess = array(
           			     'id'           => $login['id'],
                         'role'         => $login['userType'],
				        'email'         => $login['email'],
				        'name'          => $login['name'],
                        'mobile'        => $login['mobile'],
				        'logged_in'     => 1
					);

					$this->session->set_userdata($logged_in_sess);
                $response =array(
             	'status'     =>true,
             	'message'    => 'Login Successfully',
             	'relpage'    =>  base_url("welcome/dashboard")."welcome/dashboard"
             );
            }
            else{
            	$response= array(
             	'status'     =>false,
             	'message'    => 'Invalid Email And Password'
             );

            }
        }
          		else{
          $response=array(
             	'status'    =>'error',
             	'message'   => validation_errors()
             );

          		}
          	echo json_encode($response);
	}
	public function login_process()  
{    
	
            $user = $this->input->post('email');  
            $pass = $this->input->post('password');
           
       $data= $this->Model_login->log_in_correctly($user,$pass);

	   
  if ($data) 
       {
			   $newdata = array(
                   'email'  => $user,
                   'logged_in' => TRUE
               );

              $this->session->set_userdata($newdata);
             
              $this->session->set_flashdata('message', ' <div class="alert alert-success alert-dismissible fade show" role="alert">
                                  <strong>Welldone!</strong> Welcome to Dashboard
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>');
              redirect('Dashboard/welcomedashboard');        
       }
       else
       {
            $this->session->set_flashdata('message', ' <div class="alert alert-primary" style="color: red" role="alert">
  <a href="#" class="alert-link"></a> Sorry! Invalid Email And Password..
</div>');
      /*	$this->session->set_flashdata('message', 'Sorry! Invalid Email And Password.');*/
       	 redirect('Welcome/index');

       }
    }  
    public function logout()
    {
    	   $this->session->sess_destroy();
    	   redirect('Welcome/index');
    }



    public function password_cheak()
    {
          $loginemilid        =  $this->session->userdata('email');

           $newpassword        =   $this->input->post('newpassword'); 

           $email              =   $loginemilid;
           $oldpassword        =  $this->input->post('oldpassword');







          $getDetails         =    $this->Model_login->getadmindetails1($oldpassword,$email);

           $updateArray        =     array('password'=>($newpassword));
           
           $condition          =      array('email' =>$email);


                                   
           

                    
         
if($getDetails)
{

   $update           =    $this->Model_login->updateData('tbl_admin',$condition,$updateArray);
  

   if ($update=1) {
     $this->session->set_flashdata('message', ' <div class="alert alert-primary" style="background: green" role="alert">
  <a href="#" class="alert-link"></a>Password have succesfully updated.
</div>');
       redirect('Dashboard/changepassword');
   }
else
{
        $this->session->set_flashdata('message', ' <div class="alert alert-primary" style="background: green" role="alert">
  <a href="#" class="alert-link"></a> Does not valid confirm password.
</div>');
       redirect('Dashboard/changepassword');
}
    
}
  else{
    
      $this->session->set_flashdata('message', ' <div class="alert alert-primary" style="background: red" role="alert">
  <a href="#" class="alert-link"></a>Old Password does not match.
</div>');
                                                        
                                                        redirect('Dashboard/changepassword');

  }      


         



    }
}
